import exceptions.*;

import java.io.*;
import java.lang.reflect.GenericArrayType;
import java.util.*;
public class Main {
    public static void main(String[] args) throws AdamMojoudiEtebar, AdamMojoudiKala, TelephoneNaMotabar, IOException {

        ZakhireVaKhandaneEttelaat.khandaneEttelaat();

        SafheyeAsli.safheyeAsli();

        ZakhireVaKhandaneEttelaat.neveshtaneEttelaat();

    }
}

class ZakhireVaKhandaneEttelaat{
    static void neveshtaneEttelaat() throws IOException,FileNotFoundException {

        File savedData=new File("savedData");
        savedData.mkdir();

        File dasteHa=new File(savedData,"dasteHa");
        dasteHa.mkdir();
        File userHa=new File(savedData,"userHa");
        userHa.mkdir();

        File admin=new File(userHa,"admin");
        admin.mkdir();
        File kharidarHa=new File(userHa,"kharidarHa");
        kharidarHa.mkdir();
        File foroushandeHa=new File(userHa,"foroushandeHa");
        foroushandeHa.mkdir();

        File pooshak=new File(dasteHa,"pooshak");
        pooshak.mkdir();
        File khoraki=new File(dasteHa,"khoraki");
        khoraki.mkdir();
        File kalayeDigital=new File(dasteHa,"kalayeDigital");
        kalayeDigital.mkdir();
        File lavazemKhanegi=new File(dasteHa,"lavazemKhanegi");
        lavazemKhanegi.mkdir();

        File lebas=new File(pooshak,"lebas");
        lebas.mkdir();
        File kafsh=new File(pooshak,"kafsh");
        kafsh.mkdir();

        File lapTop=new File(kalayeDigital,"lapTop");
        lapTop.mkdir();
        File mobile=new File(kalayeDigital,"mobile");
        mobile.mkdir();

        File telvision=new File(lavazemKhanegi,"telvision");
        telvision.mkdir();
        File gaz=new File(lavazemKhanegi,"gaz");
        gaz.mkdir();
        File yakhchal=new File(lavazemKhanegi,"yakhchal");
        yakhchal.mkdir();

        File list1=new File(kafsh,"listKalaHa");
        list1.mkdir();
        File list2=new File(lebas,"listKalaHa");
        list2.mkdir();
        File list3=new File(telvision,"listKalaHa");
        list3.mkdir();
        File list4=new File(gaz,"listKalaHa");
        list4.mkdir();
        File list5=new File(yakhchal,"listKalaHa");
        list5.mkdir();
        File list6=new File(mobile,"listKalaHa");
        list6.mkdir();
        File list7=new File(lapTop,"listKalaHa");
        list7.mkdir();
        File list8=new File(khoraki,"listKalaHa");
        list8.mkdir();

        for (int i=0;i<Kala.kolleKalaHa.size();i++){
            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan()){
                if (Kala.kolleKalaHa.get(i) instanceof Mobile){
                    File list=new File("C:\\Users\\ali\\" +
                            "IdeaProjects\\untitled30\\savedData\\dasteHa\\kalayeDigital\\mobile\\listKalaHa","mobile"+i);
                    list.mkdir();
                    Write.writeMobile((Mobile) Kala.kolleKalaHa.get(i),"C:\\Users\\ali\\" +
                            "IdeaProjects\\untitled30\\savedData\\dasteHa\\kalayeDigital\\mobile\\listKalaHa\\mobile"+i+"\\moshakhassat.txt");

                    FileOutputStream fout=new FileOutputStream("C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\dasteHa\\kalayeDigital\\mobile\\listKalaHa\\mobile"+i+"\\nazarat.txt");
                    ObjectOutputStream os=new ObjectOutputStream(fout);
                    for(int j=0;j<Kala.kolleKalaHa.get(i).getLesteNazarat().size();j++){
                        os.writeObject(Kala.kolleKalaHa.get(i).getLesteNazarat().get(j));
                    }
                    os.close();
                    fout.close();
                }

                if (Kala.kolleKalaHa.get(i) instanceof Laptop){
                    File list=new File(lapTop,"lapTop"+i);
                    list.mkdir();
                }
                if (Kala.kolleKalaHa.get(i) instanceof Khoraki){
                    File list=new File(khoraki,"khoraki"+i);
                    list.mkdir();
                }
                if (Kala.kolleKalaHa.get(i) instanceof Yakhchal){
                    File list=new File(yakhchal,"yakhchal"+i);
                    list.mkdir();
                }
                if (Kala.kolleKalaHa.get(i) instanceof Gaz){
                    File list=new File(gaz,"gaz"+i);
                    list.mkdir();
                }
                if (Kala.kolleKalaHa.get(i) instanceof Telvesion){
                    File list=new File(telvision,"telvision"+i);
                    list.mkdir();
                }
                if (Kala.kolleKalaHa.get(i) instanceof Lebas){
                    File list=new File(lebas,"lebas"+i);
                    list.mkdir();
                }
                if (Kala.kolleKalaHa.get(i) instanceof Kafsh){
                    File list=new File(kafsh,"kafsh"+i);
                    list.mkdir();
                }
            }
        }

        sabteEttelaateAdmin();

        for (int i=0;i<HesabKarbari.getHesabKarbariHayeSakhteShode().size();i++){
            if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).isFaal()){

                if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNaghsh()==Naghsh.FOROOSHANDE){
                    File list=new File("C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\userHa\\foroushandeHa",
                            "foroushande"+i);
                    list.mkdir();
                    Write.writeForoushande((Forooshande) HesabKarbari.getHesabKarbariHayeSakhteShode().get(i),
                            "C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\userHa\\foroushandeHa\\foroushande"+i+"\\moshakhassat.txt");

                    /*FileOutputStream fout=new FileOutputStream("C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\userHa\\foroushandeHa\\foroushande"+i+"\\listFactorForoush.txt");
                    ObjectOutputStream os=new ObjectOutputStream(fout);
                    for (int j=0;j<(Forooshande)HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getFactoreForooshes().size();j++){

                    }
                    os.close();
                    fout.close();*/
                }
                if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNaghsh()==Naghsh.KHARIDAR){
                    File list=new File("C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\userHa\\kharidarHa",
                            "kharidar"+i);
                    list.mkdir();
                    Write.writeKharidar((Kharidar) HesabKarbari.getHesabKarbariHayeSakhteShode().get(i),
                            "C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\userHa\\kharidarHa\\kharidar"+i+"\\moshakhassat.txt");

                }
            }
        }
    }
    static void sabteEttelaateAdmin() throws IOException {
        PrintWriter pw=new PrintWriter("C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\userHa\\admin\\moshakhassat.txt");
        pw.println("name karbari : admin");
        pw.println("ramz : admin");
        pw.close();
        FileOutputStream fout=new FileOutputStream("C:\\Users\\ali\\IdeaProjects\\untitled30\\savedData\\userHa\\admin\\darkhastHa.txt");
        ObjectOutputStream os=new ObjectOutputStream(fout);
        for(int i=0;i<Modir.getModir().darkhastha.size();i++){
            os.writeObject(Modir.getModir().darkhastha.get(i));
        }
        os.close();
        fout.close();
    }
    static void khandaneEttelaat(){

    }
}
abstract class SafheyeAsli{
    static void safheyeAsli() throws AdamMojoudiEtebar, AdamMojoudiKala, TelephoneNaMotabar, IOException {

        Modir modir=new Modir("admin","admin");

        //dasteha bedoone karbord vali taghsim bandi kalaha bi irad
        Daste daste1=new Daste("KalayeDigital","barghi");
        Daste daste2=new Daste("Pooshak","pooshidani");
        Daste daste3=new Daste("LavazemKhanegi","barghi");
        Daste daste4=new Daste("Khoraki","Khordani");

        Scanner sc=new Scanner(System.in);
        boolean a=true;
        while (a){
            System.out.println("1.nahye karbari     2.safheye mahsoulat     3.khorouj");
            String voroodi1=sc.next();
            if(voroodi1.compareTo("1")==0){
                NahyeKarbari.NahyeKarbari();
            }
            if(voroodi1.compareTo("2")==0){
                SafheyeMahsoulat.safheyeMahsoulat();
            }
            if(voroodi1.compareTo("3")==0){
                a=false;
            }
        }
    }
}
abstract class NahyeKarbari{
    public static void NahyeKarbari() throws AdamMojoudiEtebar, AdamMojoudiKala, TelephoneNaMotabar, IOException {
        boolean b=true;
        while (b){
            System.out.println("1.sabte nam     2.lagin     3.khorouj");
            Scanner sc=new Scanner(System.in);
            String voroodi1=sc.next();
            if (voroodi1.compareTo("1")==0){
                SabteNam.sabteNam();
            }
            if (voroodi1.compareTo("2")==0){
                Lagin.lagin();
            }
            if (voroodi1.compareTo("3")==0){
                b=false;
            }
        }
    }
}
abstract class Lagin{
    static void lagin() throws AdamMojoudiEtebar, AdamMojoudiKala, TelephoneNaMotabar, IOException {
        System.out.println("name karbari?");
        Scanner sc=new Scanner(System.in);
        String voroodi1=sc.next();
        System.out.println("ramze oboor?");
        String voroodi2=sc.next();
        for (int i=0;i<HesabKarbari.getHesabKarbariHayeSakhteShode().size();i++){
            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNameKarbari().compareTo(voroodi1)==0){
                if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getRamzeOboor().compareTo(voroodi2)==0){
                    if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNaghsh()==Naghsh.FOROOSHANDE){
                        if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).isTaeideModir()){
                            System.out.println("shoma lagin shodin!");
                            HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setLogin(true);
                            BadAzLagin.badAzLagin(i);
                        }
                        else {
                            System.out.println("shoma hanouz taeid nashode eid!");
                        }
                    }
                    else {
                        System.out.println("shoma login shodin!");
                        HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setLogin(true);
                        BadAzLagin.badAzLagin(i);
                    }
                }
            }
        }
    }
}
//--------------------------------------------------
abstract class BadAzLagin{
    static void badAzLagin(int i) throws AdamMojoudiEtebar, AdamMojoudiKala, TelephoneNaMotabar, IOException {
        System.out.println("******************************************************************");
        System.out.println(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).toString());
        System.out.println("******************************************************************");
        while (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).isLogin()){
            HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setLogin(true);
            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNaghsh()==Naghsh.MODIR) {
                boolean c = true;
                while (c) {
                    System.out.println("dastresi ha:");
                    System.out.println("1.lagout                            2.thghire ettelaate shakhsi");
                    System.out.println("3.virayeshe ettelaate mahsoul       4.taeide forooshande ha");
                    System.out.println("5.taeide ezafe shodane kala         6.taeide vyrayeshe vijegihaye kala");
                    System.out.println("7.moshahedeye hameye karbaran       8.hazfe karbar!");
                    System.out.println("9.barresi vaziate nazarat     10.zakhire ettelaat");

                    String voroudi1;
                    Scanner sc = new Scanner(System.in);
                    voroudi1 = sc.next();
                    //be dalile ziad shodane tavabe karhaye modir kelase jodagane tashkil nashode digar
                    if(voroudi1.compareTo("1")==0){
                        for (int j=0;j<HesabKarbari.getHesabKarbariHayeSakhteShode().size();j++){
                            if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).isLogin()){
                                HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).setLogin(false);
                                c=false;
                            }
                        }
                    }
                    if(voroudi1.compareTo("2")==0){
                        TaghireEttelaateShakhsi.taghireEttelaateShakhsi(i);
                    }
                    if(voroudi1.compareTo("3")==0){
                        int neshan=0;
                        for (int j=1;j<HesabKarbari.getHesabKarbariHayeSakhteShode().size();j++){
                            if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).isLogin()){
                                if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()==Naghsh.FOROOSHANDE
                                        || HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()==Naghsh.MODIR) {
                                    System.out.println("esme kala?");
                                    String esm=sc.next();
                                    int neshan2=-1;
                                    for (int k=0;k<Kala.kolleKalaHa.size();k++){
                                        if(Kala.kolleKalaHa.get(k).getEsm().compareTo(esm)==0){
                                            neshan2=k;
                                        }
                                        if (neshan2==-1){
                                            System.out.println("kalaye morede nazar yaft nashod.");
                                        }
                                        else {
                                            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()==Naghsh.FOROOSHANDE){
                                                int neshan3=0;
                                                if (Kala.kolleKalaHa.get(neshan2).getForooshande().getNaghsh()==HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()){
                                                    System.out.println("new name?");
                                                    Kala.kolleKalaHa.get(neshan2).setEsm(sc.next());
                                                    System.out.println("new berand?");
                                                    Kala.kolleKalaHa.get(neshan2).setBerand(sc.next());
                                                    System.out.println("new gheimat?");
                                                    double z= HandelException.handelExceptionD();
                                                    if (z==-1.1){
                                                        try {
                                                            throw new VoroudiNaMotabar();
                                                        } catch (VoroudiNaMotabar e) {
                                                            System.out.println(e.toString());
                                                        } finally {
                                                            System.out.println("movaffagh bashid !");
                                                        }
                                                        BadAzLagin.badAzLagin(i);
                                                    }
                                                    else {
                                                        Kala.kolleKalaHa.get(neshan2).setGheimat(z);
                                                    }

                                                    System.out.println("new tozihat?");
                                                    Kala.kolleKalaHa.get(neshan2).setTozihat(sc.next());

                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof KalayeDigital){
                                                        System.out.println("new zarfiat hafeze?");
                                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatHafeze(sc.nextInt());

                                                        System.out.println("new ram?");
                                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatRam(sc.nextInt());

                                                        System.out.println("new system amel?");
                                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setSystemAmel(sc.next());

                                                        System.out.println("new vazn?");
                                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setVazn(sc.nextDouble());

                                                        System.out.println("new abad?");
                                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setAbad(sc.next());

                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Pooshak){
                                                        System.out.println("new keshvar tolid konande?");
                                                        ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setKeshvarTolidKonande(sc.next());

                                                        System.out.println("new jens?");
                                                        ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof LavazemKhanegi){
                                                        System.out.println("new daraje masraf energy?");
                                                        ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setDarajeMasrafeEnergy(sc.next());

                                                        System.out.println("new garanty?    1.darad     2.nadarad");
                                                        if (sc.nextInt()==1){
                                                            ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(true);
                                                        }
                                                        if (sc.nextInt()==2){
                                                            ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(false);
                                                        }
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Khoraki){
                                                        System.out.println("new tarikh tolid?");
                                                        ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhTolid(sc.next());

                                                        System.out.println("new tarikh engheza?");
                                                        ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhEngheza(sc.next());
                                                    }


                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Mobile){
                                                        System.out.println("new tedad sim kart?");
                                                        ((Mobile) Kala.kolleKalaHa.get(neshan2)).setTedadSimKart(sc.nextInt());

                                                        System.out.println("new keifiat dourbin?");
                                                        ((Mobile) Kala.kolleKalaHa.get(neshan2)).setKeifiatDoorbin(sc.nextInt());
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Laptop){
                                                        System.out.println("new model pardazande?");
                                                        ((Laptop) Kala.kolleKalaHa.get(neshan2)).setModelePardazande(sc.next());

                                                        System.out.println("gaming?     1.bale      2.kheir");
                                                        if (sc.nextInt()==1){
                                                            ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(true);
                                                        }
                                                        else if (sc.nextInt()==2){
                                                            ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(false);
                                                        }
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Lebas){
                                                        System.out.println("new saiz?");
                                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                                        System.out.println("new noe lebas?    1.PIRHAN    2.SHALVAR   3.T_SHIRT");

                                                        if (sc.nextInt()==1){
                                                            ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.PIRHAN);
                                                        }
                                                        else if (sc.nextInt()==2){
                                                            ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.SHALVAR);
                                                        }
                                                        else if (sc.nextInt()==3){
                                                            ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.T_SHIRT);
                                                        }
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Kafsh){
                                                        System.out.println("new saiz?");
                                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                                        System.out.println("new noe kafsh?      1.BOOT      2.MAJLESI    3.SPORT");
                                                        if (sc.nextInt()==1){
                                                            ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.BOOT);
                                                        }
                                                        else if (sc.nextInt()==2){
                                                            ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.MAJLESI);
                                                        }
                                                        else if (sc.nextInt()==3){
                                                            ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.SPORT);
                                                        }
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Telvesion){
                                                        System.out.println("new keyfiat tasvir?");
                                                        ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setKeifiatTasvir(sc.next());
                                                        System.out.println("new size?");
                                                        ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setSizeSafheNamayesh(sc.nextDouble());
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Yakhchal){
                                                        System.out.println("new gonjayesh?");
                                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setGonjayesh(sc.nextDouble());

                                                        System.out.println("new noe yakhchal?");
                                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setNoeYakhchal(sc.next());

                                                        System.out.println("aya fereizer darad?     1.bale     2.kheir");
                                                        if (sc.nextInt()==1){
                                                            ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(true);
                                                        }
                                                        else if (sc.nextInt()==2){
                                                            ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(false);
                                                        }
                                                    }
                                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Gaz){
                                                        System.out.println("new tedad shole?");
                                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setTedadShole(sc.nextInt());

                                                        System.out.println("new jens?");
                                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());

                                                        System.out.println("aya fer darad?      1.bale      2.kheir");
                                                        if (sc.nextInt()==1){
                                                            ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(true);
                                                        }
                                                        else if (sc.nextInt()==2){
                                                            ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(false);
                                                        }
                                                    }
                                                }
                                            }
                                            else {
                                                System.out.println("new name?");
                                                Kala.kolleKalaHa.get(neshan2).setEsm(sc.next());
                                                System.out.println("new berand?");
                                                Kala.kolleKalaHa.get(neshan2).setBerand(sc.next());
                                                System.out.println("new gheimat?");
                                                Kala.kolleKalaHa.get(neshan2).setGheimat(sc.nextDouble());
                                                System.out.println("new tozihat?");
                                                Kala.kolleKalaHa.get(neshan2).setTozihat(sc.next());

                                                if (Kala.kolleKalaHa.get(neshan2) instanceof KalayeDigital){
                                                    System.out.println("new zarfiat hafeze?");
                                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatHafeze(sc.nextInt());

                                                    System.out.println("new ram?");
                                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatRam(sc.nextInt());

                                                    System.out.println("new system amel?");
                                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setSystemAmel(sc.next());

                                                    System.out.println("new vazn?");
                                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setVazn(sc.nextDouble());

                                                    System.out.println("new abad?");
                                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setAbad(sc.next());

                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Pooshak){
                                                    System.out.println("new keshvar tolid konande?");
                                                    ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setKeshvarTolidKonande(sc.next());

                                                    System.out.println("new jens?");
                                                    ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof LavazemKhanegi){
                                                    System.out.println("new daraje masraf energy?");
                                                    ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setDarajeMasrafeEnergy(sc.next());

                                                    System.out.println("new garanty?    1.darad     2.nadarad");
                                                    if (sc.nextInt()==1){
                                                        ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(true);
                                                    }
                                                    if (sc.nextInt()==2){
                                                        ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(false);
                                                    }
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Khoraki){
                                                    System.out.println("new tarikh tolid?");
                                                    ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhTolid(sc.next());

                                                    System.out.println("new tarikh engheza?");
                                                    ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhEngheza(sc.next());
                                                }


                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Mobile){
                                                    System.out.println("new tedad sim kart?");
                                                    ((Mobile) Kala.kolleKalaHa.get(neshan2)).setTedadSimKart(sc.nextInt());

                                                    System.out.println("new keifiat dourbin?");
                                                    ((Mobile) Kala.kolleKalaHa.get(neshan2)).setKeifiatDoorbin(sc.nextInt());
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Laptop){
                                                    System.out.println("new model pardazande?");
                                                    ((Laptop) Kala.kolleKalaHa.get(neshan2)).setModelePardazande(sc.next());

                                                    System.out.println("gaming?     1.bale      2.kheir");
                                                    if (sc.nextInt()==1){
                                                        ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(true);
                                                    }
                                                    else if (sc.nextInt()==2){
                                                        ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(false);
                                                    }
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Lebas){
                                                    System.out.println("new saiz?");
                                                    ((Lebas) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                                    System.out.println("new noe lebas?    1.PIRHAN    2.SHALVAR   3.T_SHIRT");

                                                    if (sc.nextInt()==1){
                                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.PIRHAN);
                                                    }
                                                    else if (sc.nextInt()==2){
                                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.SHALVAR);
                                                    }
                                                    else if (sc.nextInt()==3){
                                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.T_SHIRT);
                                                    }
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Kafsh){
                                                    System.out.println("new saiz?");
                                                    ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                                    System.out.println("new noe kafsh?      1.BOOT      2.MAJLESI    3.SPORT");
                                                    if (sc.nextInt()==1){
                                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.BOOT);
                                                    }
                                                    else if (sc.nextInt()==2){
                                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.MAJLESI);
                                                    }
                                                    else if (sc.nextInt()==3){
                                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.SPORT);
                                                    }
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Telvesion){
                                                    System.out.println("new keyfiat tasvir?");
                                                    ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setKeifiatTasvir(sc.next());
                                                    System.out.println("new size?");
                                                    ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setSizeSafheNamayesh(sc.nextDouble());
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Yakhchal){
                                                    System.out.println("new gonjayesh?");
                                                    ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setGonjayesh(sc.nextDouble());

                                                    System.out.println("new noe yakhchal?");
                                                    ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setNoeYakhchal(sc.next());

                                                    System.out.println("aya fereizer darad?     1.bale     2.kheir");
                                                    if (sc.nextInt()==1){
                                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(true);
                                                    }
                                                    else if (sc.nextInt()==2){
                                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(false);
                                                    }
                                                }
                                                if (Kala.kolleKalaHa.get(neshan2) instanceof Gaz){
                                                    System.out.println("new tedad shole?");
                                                    ((Gaz) Kala.kolleKalaHa.get(neshan2)).setTedadShole(sc.nextInt());

                                                    System.out.println("new jens?");
                                                    ((Gaz) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());

                                                    System.out.println("aya fer darad?      1.bale      2.kheir");
                                                    if (sc.nextInt()==1){
                                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(true);
                                                    }
                                                    else if (sc.nextInt()==2){
                                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(false);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else {
                                    System.out.println("voroude shoma gheire mojaz mibashad!");
                                }
                                j=HesabKarbari.getHesabKarbariHayeSakhteShode().size();
                            }
                        }
                    }
                    if(voroudi1.compareTo("4")==0){
                        System.out.println("nam haye karbarie forooshande haye taeid nashode : ");
                        for (int k = 0; k < HesabKarbari.getHesabKarbariHayeSakhteShode().size(); k++) {
                            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).getNaghsh() == Naghsh.FOROOSHANDE &&
                                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).isTaeideModir() == false) {
                                System.out.println(HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).toString());
                            }
                        }
                        System.out.println("**************************************");
                        System.out.println("name user taeidi ra vared konid : ");
                        String nameUserTaeidi=sc.next();
                        for (int k = 0; k < HesabKarbari.getHesabKarbariHayeSakhteShode().size(); k++) {
                            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).getNaghsh() == Naghsh.FOROOSHANDE &&
                                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).isTaeideModir() == false &&
                                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).getNameKarbari().compareTo(
                                            nameUserTaeidi)==0){
                                HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).setTaeideModir(true);
                                System.out.println("taeid shod!");
                                k = HesabKarbari.getHesabKarbariHayeSakhteShode().size();
                                c=false;
                            }
                        }
                    }
                    if(voroudi1.compareTo("5")==0){
                        System.out.println("liste kalahaye taeid nashode : ");
                        for (int k=0;k<Kala.kolleKalaHa.size();k++){
                            if (Kala.kolleKalaHa.get(k).isVaziateTaeideEzafeShodan()==false){
                                System.out.println(Kala.kolleKalaHa.get(k).toString());
                            }
                        }
                        boolean p=true;
                        while (p){
                            System.out.println("jahate taeide kalaye madde nazar shenase ash ra vared konid : ");
                            int shenase=sc.nextInt();
                            for (int k=0;k<Kala.kolleKalaHa.size();k++){
                                if (Kala.kolleKalaHa.get(k).getShenaseKala()==shenase){
                                    Kala.kolleKalaHa.get(k).setVaziateTaeideEzafeShodan(true);
                                    k=Kala.kolleKalaHa.size();
                                }
                            }
                            System.out.println("1.edame    2.payan?");
                            int edameYaPayan=sc.nextInt();
                            if (edameYaPayan==2){
                                p=false;
                            }
                        }
                    }
                    if(voroudi1.compareTo("6")==0){
                        System.out.println("kalahaye darhasti (vyrayesh) : ");
                        for (int k=0;k<Kala.kolleKalaHa.size();k++){
                            if (Kala.kolleKalaHa.get(k).getVaziateDarkhasteTaghireEtteleat()==
                                    VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR){
                                System.out.println(Kala.kolleKalaHa.get(k).toString());
                            }
                        }
                        System.out.println("aydi kalaye taeidi ra vared konid : ");
                        int id=sc.nextInt();
                        for (int k=0;k<Kala.kolleKalaHa.size();k++){
                            if (Kala.kolleKalaHa.get(k).getVaziateDarkhasteTaghireEtteleat()==
                                    VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR &&
                                    Kala.kolleKalaHa.get(k).getShenaseKala()==id){
                                Kala.kolleKalaHa.get(k).setVaziateDarkhasteTaghireEtteleat(VaziateDarkhasteTaghireEtteleat.TAEID);
                            }
                        }
                    }
                    if(voroudi1.compareTo("7")==0){
                        for (int k=1;k<HesabKarbari.getHesabKarbariHayeSakhteShode().size();k++){
                            System.out.println(HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).toString());
                        }
                    }
                    if(voroudi1.compareTo("8")==0){
                        System.out.println("karbaran : ");
                        for (int k=1;k<HesabKarbari.getHesabKarbariHayeSakhteShode().size();k++){
                            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).isFaal()){
                                System.out.println(HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).toString());
                            }
                        }
                        System.out.println("name karbarie karbare hazfi ra vared konid : ");
                        String nam=sc.next();
                        for (int k=1;k<HesabKarbari.getHesabKarbariHayeSakhteShode().size();k++){
                            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).getNameKarbari().compareTo(nam)==0){
                                HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).setFaal(false);
                            }
                        }
                    }
                    if(voroudi1.compareTo("9")==0){
                        BarresiNazar.barresiNazar(i);
                    }
                    if(voroudi1.compareTo("10")==0){
                        ZakhireVaKhandaneEttelaat.neveshtaneEttelaat();
                    }
                }
            }
            else if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNaghsh()==Naghsh.FOROOSHANDE) {
                HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setLogin(true);
                boolean c = true;
                while (c) {
                    System.out.println("dastresi ha:");
                    System.out.println("1.lagout           2.thghire ettelaate shakhsi");
                    System.out.println("3.ezafe kardane kalaye jadid va foroush ");
                    System.out.println("4.virayeshe ettelaate mahsoul      5.hazfe mahsoul");
                    String voroudi1;
                    Scanner sc = new Scanner(System.in);
                    voroudi1 = sc.next();
                    if(voroudi1.compareTo("1")==0){
                        for (int j=0;j<HesabKarbari.getHesabKarbariHayeSakhteShode().size();j++){
                            if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).isLogin()){
                                HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).setLogin(false);
                                c=false;
                            }
                        }
                    }
                    if(voroudi1.compareTo("2")==0){
                        TaghireEttelaateShakhsi.taghireEttelaateShakhsi(i);
                    }
                    if(voroudi1.compareTo("3")==0){
                        EzafeKardaneKalayeJadid.ezafeKardaneKalayeJadid(i);
                    }
                    if(voroudi1.compareTo("4")==0){
                        VirayesheEttelaateMahsoul.virayesheEttelaateMahsoul(i);
                    }
                    if(voroudi1.compareTo("5")==0){
                        HazfeMahsoul.hazfeMahsoul(i);
                    }
                }
            }
            else if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNaghsh()==Naghsh.KHARIDAR) {
                HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setLogin(true);
                boolean c = true;
                while (c) {
                    System.out.println("dastresi ha:");
                    System.out.println("1.lagout       2.thghire ettelaate shakhsi");
                    System.out.println("3.moshahede sabade kharid      4.nomre dahi ");
                    System.out.println("5.safheye mahsoulat");
                    String voroudi1;
                    Scanner sc = new Scanner(System.in);
                    voroudi1 = sc.next();
                    if(voroudi1.compareTo("1")==0){
                        for (int j=0;j<HesabKarbari.getHesabKarbariHayeSakhteShode().size();j++){
                            if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).isLogin()){
                                HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).setLogin(false);
                                c=false;
                            }
                        }
                    }
                    if(voroudi1.compareTo("2")==0){
                        TaghireEttelaateShakhsi.taghireEttelaateShakhsi(i);
                    }
                    if(voroudi1.compareTo("3")==0){
                        MoshahedeSabadeKharid.moshahedeSabadeKharid();
                    }
                    if(voroudi1.compareTo("4")==0){
                        NomreDahi.nomreDahi(i);
                    }
                    if (voroudi1.compareTo("5")==0){
                        SafheyeMahsoulat.safheyeMahsoulat();
                    }
                }
            }
        }
    }
}
abstract class SabteNam{
    static int idShomarandeSabteNamiHa=0;
    static void sabteNam() throws TelephoneNaMotabar {
        Kharidar kharidar=new Kharidar();
        Forooshande forooshande=new Forooshande();
        Scanner sc=new Scanner(System.in);
        int voroodi2;
        String voroodi1;
        boolean a=true;
        boolean b=true;
        while (a){
            System.out.println("naghsh?     1.kharidar     2.forooshande");
            voroodi1=sc.next();
            if(voroodi1.compareTo("1")==0){
                kharidar.setNaghsh(Naghsh.KHARIDAR);

                b=true;
                System.out.println("name karbari?");
                while (b) {
                    voroodi1 = sc.next();
                    int neshane=0;
                    for (int i=0;i<HesabKarbari.getHesabKarbariHayeSakhteShode().size();i++){
                        if(voroodi1.compareTo(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNameKarbari())==0){
                            neshane=1;
                        }
                    }
                    if(neshane==0){
                        kharidar.setNameKarbari(voroodi1);
                        b=false;
                    }
                    else if(neshane==1){
                        System.out.println("in name karbari sabt shode ast!");
                        System.out.println("");
                        System.out.println("name karbari digari vared konid:");
                    }
                }
                System.out.println("name?");
                voroodi1=sc.next();
                kharidar.setNam(voroodi1);

                System.out.println("name khanevadegi?");
                voroodi1=sc.next();
                kharidar.setNameKhanevadegi(voroodi1);

                System.out.println("email?");
                voroodi1=sc.next();
                int natije=HandelException.barresiEmail(voroodi1);
                if (natije==0){
                    try {
                        throw new EmailNaMotabar();
                    } catch (EmailNaMotabar e) {
                        System.out.println(e.toString());
                        SabteNam.sabteNam();
                    }
                    finally {
                        System.out.println("movaffagh bashid !");
                    }
                }
                else {
                    kharidar.setEmail(voroodi1);
                }

                System.out.println("shomare telephone?");

                long nesh=HandelException.handelShomareTelephone();
                if (nesh==-1) {
                    try {
                        throw new TelephoneNaMotabar();
                    } catch (TelephoneNaMotabar e) {
                        System.out.println(e.toString());
                        SabteNam.sabteNam();
                    }
                    finally {
                        System.out.println("movaffagh bashid !");
                    }
                }
                else {
                    kharidar.setShomareTelephon(nesh);
                }

                System.out.println("ramze oboor?");
                voroodi1=sc.next();
                kharidar.setRamzeOboor(voroodi1);

                System.out.println("etebar?");
                String voroodi3=sc.next();
                voroodi2=Integer.parseInt(voroodi3);
                kharidar.setEtebar(voroodi2);
                kharidar.setIdShomarandeSabteNamiHa(idShomarandeSabteNamiHa);
                idShomarandeSabteNamiHa++;
                voroodi1="a";
                HesabKarbari.ezafeKardanHesabHayeSakhteShode(kharidar);
                a=false;
            }
            if (voroodi1.compareTo("2")==0){
                forooshande.setNaghsh(Naghsh.FOROOSHANDE);
                System.out.println("name karbari?");
                while (b) {
                    voroodi1 = sc.next();
                    int neshane=0;
                    for (int i=0;i<HesabKarbari.getHesabKarbariHayeSakhteShode().size();i++){
                        if(voroodi1.compareTo(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getNameKarbari())==0){
                            neshane=1;
                        }
                    }
                    if(neshane==0){
                        forooshande.setNameKarbari(voroodi1);
                        b=false;
                    }
                    else if(neshane==1){
                        System.out.println("in name karbari sabt shode ast!");
                        System.out.println("");
                        System.out.println("name karbari digari vared konid:");
                    }
                }
                Modir.getDarkhastha().add(voroodi1);

                System.out.println("name?");
                voroodi1=sc.next();
                forooshande.setNam(voroodi1);

                System.out.println("name khanevadegi?");
                voroodi1=sc.next();
                forooshande.setNameKhanevadegi(voroodi1);

                System.out.println("email?");
                voroodi1=sc.next();
                int natije=HandelException.barresiEmail(voroodi1);
                if (natije==0){
                    try {
                        throw new EmailNaMotabar();
                    } catch (EmailNaMotabar e) {
                        System.out.println(e.toString());
                        SabteNam.sabteNam();
                    }
                    finally {
                        System.out.println("movaffagh bashid !");
                    }
                }
                else {
                    kharidar.setEmail(voroodi1);
                }

                System.out.println("shomare telephone?");

                long nesh=HandelException.handelShomareTelephone();
                if (nesh==-1) {
                    try {
                        throw new TelephoneNaMotabar();
                    } catch (TelephoneNaMotabar e) {
                        System.out.println(e.toString());
                        SabteNam.sabteNam();
                    }
                    finally {
                        System.out.println("movaffagh bashid !");
                    }
                }
                else {
                    forooshande.setShomareTelephon(nesh);
                }


                System.out.println("ramze oboor?");
                voroodi1=sc.next();
                forooshande.setRamzeOboor(voroodi1);

                System.out.println("etebar?");
                String voroodi3=sc.next();
                voroodi2=Integer.parseInt(voroodi3);
                forooshande.setEtebar(voroodi2);

                System.out.println("esme sherkat?");
                voroodi3=sc.next();
                forooshande.setEsmeSherkat(voroodi3);

                System.out.println("esme kargah?");
                voroodi3=sc.next();
                forooshande.setEsmeKargah(voroodi3);

                System.out.println("esme karkhane?");
                voroodi3=sc.next();
                forooshande.setEsmeKarkhane(voroodi3);

                idShomarandeSabteNamiHa++;

                HesabKarbari.ezafeKardanHesabHayeSakhteShode(forooshande);
                a=false;
            }
        }
    }
}
abstract class TaghireEttelaateShakhsi{
    static void taghireEttelaateShakhsi(int i){
        Scanner sc=new Scanner(System.in);
        String  voroodi1;
        int voroodi2;
        System.out.println("new name?");
        voroodi1=sc.next();
        HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setNam(voroodi1);

        System.out.println("new name khanevadegi?");
        voroodi1=sc.next();
        HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setNameKhanevadegi(voroodi1);

        System.out.println("new email?");

        voroodi1=sc.next();
        int natije=HandelException.barresiEmail(voroodi1);
        if (natije==0){
            try {
                throw new EmailNaMotabar();
            } catch (EmailNaMotabar e) {
                System.out.println(e.toString());
                taghireEttelaateShakhsi(i);
            }
            finally {
                System.out.println("movaffagh bashid !");
            }
        }
        else {
            HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setEmail(voroodi1);
        }

        System.out.println("new shomare telephone?");

        long nesh=HandelException.handelShomareTelephone();
        if (nesh==-1) {
            try {
                throw new TelephoneNaMotabar();
            } catch (TelephoneNaMotabar e) {
                System.out.println(e.toString());
                taghireEttelaateShakhsi(i);
            }
            finally {
                System.out.println("movaffagh bashid !");
            }
        }
        else {
            HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setShomareTelephon(nesh);
        }


        System.out.println("new ramze oboor?");
        voroodi1=sc.next();
        HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setRamzeOboor(voroodi1);

        System.out.println("new etebar?");
        voroodi1=sc.next();
        voroodi2=Integer.parseInt(voroodi1);
        HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).setEtebar(voroodi2);
    }
}
abstract class VirayesheEttelaateMahsoul{
    public static void virayesheEttelaateMahsoul(int i){
        Scanner sc=new Scanner(System.in);
        int neshan=0;
        for (int j=1;j<HesabKarbari.getHesabKarbariHayeSakhteShode().size();j++){
            if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).isLogin()){
                if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()==Naghsh.FOROOSHANDE
                        || HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()==Naghsh.MODIR) {
                    System.out.println("esme kala?");
                    String esm=sc.next();
                    int neshan2=-1;
                    for (int k=0;k<Kala.kolleKalaHa.size();k++){
                        if(Kala.kolleKalaHa.get(k).getEsm().compareTo(esm)==0){
                            neshan2=k;
                        }
                        if (neshan2==-1){
                            System.out.println("kalaye morede nazar yaft nashod.");
                        }
                        else {
                            Kala.kolleKalaHa.get(neshan2).setVaziateDarkhasteTaghireEtteleat(VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR);

                            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()==Naghsh.FOROOSHANDE){
                                if (Kala.kolleKalaHa.get(neshan2).getForooshande().getNaghsh()==HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).getNaghsh()){
                                    System.out.println("new name?");
                                    Kala.kolleKalaHa.get(neshan2).setEsm(sc.next());
                                    System.out.println("new berand?");
                                    Kala.kolleKalaHa.get(neshan2).setBerand(sc.next());
                                    System.out.println("new gheimat?");
                                    Kala.kolleKalaHa.get(neshan2).setGheimat(sc.nextDouble());
                                    System.out.println("new tozihat?");
                                    Kala.kolleKalaHa.get(neshan2).setTozihat(sc.next());

                                    if (Kala.kolleKalaHa.get(neshan2) instanceof KalayeDigital){
                                        System.out.println("new zarfiat hafeze?");
                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatHafeze(sc.nextInt());

                                        System.out.println("new ram?");
                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatRam(sc.nextInt());

                                        System.out.println("new system amel?");
                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setSystemAmel(sc.next());

                                        System.out.println("new vazn?");
                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setVazn(sc.nextDouble());

                                        System.out.println("new abad?");
                                        ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setAbad(sc.next());

                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Pooshak){
                                        System.out.println("new keshvar tolid konande?");
                                        ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setKeshvarTolidKonande(sc.next());

                                        System.out.println("new jens?");
                                        ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());

                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof LavazemKhanegi){
                                        System.out.println("new daraje masraf energy?");
                                        ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setDarajeMasrafeEnergy(sc.next());

                                        System.out.println("new garanty?    1.darad     2.nadarad");

                                        if (sc.nextInt()==1){
                                            ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(true);
                                        }
                                        if (sc.nextInt()==2){
                                            ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(false);
                                        }
                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Khoraki){
                                        System.out.println("new tarikh tolid?");
                                        ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhTolid(sc.next());

                                        System.out.println("new tarikh engheza?");
                                        ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhEngheza(sc.next());
                                    }


                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Mobile){
                                        System.out.println("new tedad sim kart?");
                                        ((Mobile) Kala.kolleKalaHa.get(neshan2)).setTedadSimKart(sc.nextInt());

                                        System.out.println("new keifiat dourbin?");
                                        ((Mobile) Kala.kolleKalaHa.get(neshan2)).setKeifiatDoorbin(sc.nextInt());
                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Laptop){
                                        System.out.println("new model pardazande?");
                                        ((Laptop) Kala.kolleKalaHa.get(neshan2)).setModelePardazande(sc.next());

                                        System.out.println("gaming?     1.bale      2.kheir");
                                        if (sc.nextInt()==1){
                                            ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(true);
                                        }
                                        else if (sc.nextInt()==2){
                                            ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(false);
                                        }
                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Lebas){
                                        System.out.println("new saiz?");
                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                        System.out.println("new noe lebas?    1.PIRHAN    2.SHALVAR   3.T_SHIRT");

                                        if (sc.nextInt()==1){
                                            ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.PIRHAN);
                                        }
                                        else if (sc.nextInt()==2){
                                            ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.SHALVAR);
                                        }
                                        else if (sc.nextInt()==3){
                                            ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.T_SHIRT);
                                        }
                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Kafsh){
                                        System.out.println("new saiz?");
                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                        System.out.println("new noe kafsh?      1.BOOT      2.MAJLESI    3.SPORT");
                                        if (sc.nextInt()==1){
                                            ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.BOOT);
                                        }
                                        else if (sc.nextInt()==2){
                                            ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.MAJLESI);
                                        }
                                        else if (sc.nextInt()==3){
                                            ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.SPORT);
                                        }
                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Telvesion){
                                        System.out.println("new keyfiat tasvir?");
                                        ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setKeifiatTasvir(sc.next());
                                        System.out.println("new size?");
                                        ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setSizeSafheNamayesh(sc.nextDouble());
                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Yakhchal){
                                        System.out.println("new gonjayesh?");
                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setGonjayesh(sc.nextDouble());

                                        System.out.println("new noe yakhchal?");
                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setNoeYakhchal(sc.next());

                                        System.out.println("aya fereizer darad?     1.bale     2.kheir");
                                        if (sc.nextInt()==1){
                                            ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(true);
                                        }
                                        else if (sc.nextInt()==2){
                                            ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(false);
                                        }
                                    }
                                    if (Kala.kolleKalaHa.get(neshan2) instanceof Gaz){
                                        System.out.println("new tedad shole?");
                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setTedadShole(sc.nextInt());

                                        System.out.println("new jens?");
                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());

                                        System.out.println("aya fer darad?      1.bale      2.kheir");
                                        if (sc.nextInt()==1){
                                            ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(true);
                                        }
                                        else if (sc.nextInt()==2){
                                            ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(false);
                                        }
                                    }
                                }
                            }
                            else {
                                System.out.println("new name?");
                                Kala.kolleKalaHa.get(neshan2).setEsm(sc.next());
                                System.out.println("new berand?");
                                Kala.kolleKalaHa.get(neshan2).setBerand(sc.next());
                                System.out.println("new gheimat?");
                                Kala.kolleKalaHa.get(neshan2).setGheimat(sc.nextDouble());
                                System.out.println("new tozihat?");
                                Kala.kolleKalaHa.get(neshan2).setTozihat(sc.next());

                                if (Kala.kolleKalaHa.get(neshan2) instanceof KalayeDigital){
                                    System.out.println("new zarfiat hafeze?");
                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatHafeze(sc.nextInt());

                                    System.out.println("new ram?");
                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setZarfiatRam(sc.nextInt());

                                    System.out.println("new system amel?");
                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setSystemAmel(sc.next());

                                    System.out.println("new vazn?");
                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setVazn(sc.nextDouble());

                                    System.out.println("new abad?");
                                    ((KalayeDigital) Kala.kolleKalaHa.get(neshan2)).setAbad(sc.next());

                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Pooshak){
                                    System.out.println("new keshvar tolid konande?");
                                    ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setKeshvarTolidKonande(sc.next());

                                    System.out.println("new jens?");
                                    ((Pooshak) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof LavazemKhanegi){
                                    System.out.println("new daraje masraf energy?");
                                    ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setDarajeMasrafeEnergy(sc.next());

                                    System.out.println("new garanty?    1.darad     2.nadarad");
                                    if (sc.nextInt()==1){
                                        ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(true);
                                    }
                                    if (sc.nextInt()==2){
                                        ((LavazemKhanegi) Kala.kolleKalaHa.get(neshan2)).setGaranty(false);
                                    }
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Khoraki){
                                    System.out.println("new tarikh tolid?");
                                    ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhTolid(sc.next());

                                    System.out.println("new tarikh engheza?");
                                    ((Khoraki) Kala.kolleKalaHa.get(neshan2)).setTarikhEngheza(sc.next());
                                }


                                if (Kala.kolleKalaHa.get(neshan2) instanceof Mobile){
                                    System.out.println("new tedad sim kart?");
                                    ((Mobile) Kala.kolleKalaHa.get(neshan2)).setTedadSimKart(sc.nextInt());

                                    System.out.println("new keifiat dourbin?");
                                    ((Mobile) Kala.kolleKalaHa.get(neshan2)).setKeifiatDoorbin(sc.nextInt());
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Laptop){
                                    System.out.println("new model pardazande?");
                                    ((Laptop) Kala.kolleKalaHa.get(neshan2)).setModelePardazande(sc.next());

                                    System.out.println("gaming?     1.bale      2.kheir");
                                    if (sc.nextInt()==1){
                                        ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(true);
                                    }
                                    else if (sc.nextInt()==2){
                                        ((Laptop) Kala.kolleKalaHa.get(neshan2)).setGaming(false);
                                    }
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Lebas){
                                    System.out.println("new saiz?");
                                    ((Lebas) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                    System.out.println("new noe lebas?    1.PIRHAN    2.SHALVAR   3.T_SHIRT");

                                    if (sc.nextInt()==1){
                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.PIRHAN);
                                    }
                                    else if (sc.nextInt()==2){
                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.SHALVAR);
                                    }
                                    else if (sc.nextInt()==3){
                                        ((Lebas) Kala.kolleKalaHa.get(neshan2)).setNoeLebas(NoeLebas.T_SHIRT);
                                    }
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Kafsh){
                                    System.out.println("new saiz?");
                                    ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setSize(sc.nextInt());

                                    System.out.println("new noe kafsh?      1.BOOT      2.MAJLESI    3.SPORT");
                                    if (sc.nextInt()==1){
                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.BOOT);
                                    }
                                    else if (sc.nextInt()==2){
                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.MAJLESI);
                                    }
                                    else if (sc.nextInt()==3){
                                        ((Kafsh) Kala.kolleKalaHa.get(neshan2)).setNoeKafsh(NoeKafsh.SPORT);
                                    }
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Telvesion){
                                    System.out.println("new keyfiat tasvir?");
                                    ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setKeifiatTasvir(sc.next());
                                    System.out.println("new size?");
                                    ((Telvesion) Kala.kolleKalaHa.get(neshan2)).setSizeSafheNamayesh(sc.nextDouble());
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Yakhchal){
                                    System.out.println("new gonjayesh?");
                                    ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setGonjayesh(sc.nextDouble());

                                    System.out.println("new noe yakhchal?");
                                    ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setNoeYakhchal(sc.next());

                                    System.out.println("aya fereizer darad?     1.bale     2.kheir");
                                    if (sc.nextInt()==1){
                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(true);
                                    }
                                    else if (sc.nextInt()==2){
                                        ((Yakhchal) Kala.kolleKalaHa.get(neshan2)).setFereizer(false);
                                    }
                                }
                                if (Kala.kolleKalaHa.get(neshan2) instanceof Gaz){
                                    System.out.println("new tedad shole?");
                                    ((Gaz) Kala.kolleKalaHa.get(neshan2)).setTedadShole(sc.nextInt());

                                    System.out.println("new jens?");
                                    ((Gaz) Kala.kolleKalaHa.get(neshan2)).setJens(sc.next());

                                    System.out.println("aya fer darad?      1.bale      2.kheir");
                                    if (sc.nextInt()==1){
                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(true);
                                    }
                                    else if (sc.nextInt()==2){
                                        ((Gaz) Kala.kolleKalaHa.get(neshan2)).setFer(false);
                                    }
                                }
                            }
                        }
                    }
                }
                else {
                    System.out.println("voroude shoma gheire mojaz mibashad!");
                }
                j=HesabKarbari.getHesabKarbariHayeSakhteShode().size();
            }
        }
    }
}
abstract class EzafeKardaneKalayeJadid {
    public static void ezafeKardaneKalayeJadid(int i) {
        Scanner sc = new Scanner(System.in);
        int neshan = -1;
        for (int j = 0; j < HesabKarbari.getHesabKarbariHayeSakhteShode().size(); j++) {
            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).isLogin()) {
                neshan = j;
            }
        }
        if (neshan == -1) {
            System.out.println("shoma lagin nistin!");
        } else {

            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getNaghsh() == Naghsh.FOROOSHANDE) {
                String voroudi2;
                boolean f = true;
                while (f) {
                    String voroudi3, voroudi4, voroudi5, voroudi8, voroudi10;
                    double voroudi6;
                    Forooshande voroudi7;
                    boolean voroudi9 = true;
                    System.out.println("ezafe kardane kalaye jadid!");
                    System.out.println("esm kala?");
                    voroudi3 = sc.next();
                    System.out.println("berand kala?");
                    voroudi4 = sc.next();
                    System.out.println("gheimat kala?");
                    voroudi5 = sc.next();
                    voroudi6 = Double.parseDouble(voroudi5);
                    voroudi7 = (Forooshande) HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan);
                    boolean h = true;
                    while (h) {
                        System.out.println("mojoudi kala?      1.bale      2.kheir");
                        voroudi8 = sc.next();
                        if (voroudi8.compareTo("1") == 0) {
                            voroudi9 = true;
                            h = false;
                        }
                        if (voroudi8.compareTo("2") == 0) {
                            voroudi9 = false;
                            h = false;
                        }
                    }
                    System.out.println("tozihat kala?");
                    voroudi10 = sc.next();
                    double voroudi11;
                    voroudi11 = 0.0;

                    String voroudi12, voroudi13, voroudi14, voroudi15, voroudi16, voroudi17, voroudi18, voroudi19, voroudi20;
                    int voroudi21 = 0, voroudi22 = 0, voroudi23, voroudi24, voroudi25;
                    double voroudi26 = 0, voroudi27, voroudi28, voroudi29;
                    boolean ab1, ab2 = false, ab3 = false;
                    boolean k = true;
                    while (k) {
                        System.out.println("1.kalaye digital        2.pooshak");
                        System.out.println("3.lavazem khanegi       4.khoraki");
                        voroudi12 = sc.next();
                        if (voroudi12.compareTo("1") == 0) {
                            System.out.println("zarfiat hafeze?");
                            voroudi21 = sc.nextInt();
                            System.out.println("zarfiat ram?");
                            voroudi22 = sc.nextInt();
                            System.out.println("system amel?");
                            voroudi13 = sc.next();
                            System.out.println("vazn?");
                            voroudi26 = sc.nextDouble();
                            System.out.println("abad?");
                            voroudi15 = sc.next();
                            boolean l = true;
                            while (l) {
                                System.out.println("1.mobail    2.laptap?");
                                voroudi13 = sc.next();
                                if (voroudi13.compareTo("1") == 0) {
                                    System.out.println("tedad sim kart?");
                                    voroudi23 = sc.nextInt();
                                    System.out.println("keifiat dourbin?");
                                    voroudi24 = sc.nextInt();
                                    Mobile mobile = new Mobile(voroudi3, voroudi4, voroudi6,
                                            voroudi7, voroudi9, voroudi10, voroudi21, voroudi22, voroudi13,
                                            voroudi26, voroudi15, voroudi23, voroudi24);
                                    Modir.getAfzoodaneKala(mobile);
                                    k = false;
                                    l = false;
                                }
                                if (voroudi13.compareTo("2") == 0) {
                                    System.out.println("model pardazande?");
                                    voroudi14 = sc.next();
                                    System.out.println("aya gaming ast?     1.bale      2.kheir");
                                    voroudi21 = sc.nextInt();
                                    if (voroudi21 == 1) {
                                        ab1 = true;
                                    } else if (voroudi21 == 2) {
                                        ab1 = false;
                                    } else {
                                        ab1 = false;
                                    }
                                    Laptop laptop = new Laptop(voroudi3, voroudi4, voroudi6,
                                            voroudi7, voroudi9, voroudi10, voroudi21, voroudi22, voroudi13,
                                            voroudi26, voroudi15, voroudi14, ab1);
                                    Modir.getAfzoodaneKala(laptop);
                                    k = false;
                                    l = false;
                                }
                            }
                            f = false;
                        }
                        if (voroudi12.compareTo("2") == 0) {
                            System.out.println("keshvar tolid konande?");
                            voroudi13 = sc.next();
                            System.out.println("jens?");
                            voroudi14 = sc.next();
                            ab1 = true;
                            while (ab1) {
                                System.out.println("1.lebas     2.kafsh?");
                                voroudi20 = sc.next();
                                if (voroudi20.compareTo("1") == 0) {
                                    System.out.println("saiz?");
                                    voroudi24 = sc.nextInt();
                                    System.out.println("che lebasi?");
                                    System.out.println("1.T_SHIRT       2.SHALVAR       3.PIRHAN");
                                    voroudi23 = sc.nextInt();
                                    if (voroudi23 == 1) {
                                        Lebas lebas = new Lebas(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                                voroudi13, voroudi14, voroudi24, NoeLebas.T_SHIRT);
                                        Modir.getAfzoodaneKala(lebas);
                                        k = false;
                                        f = false;
                                    }
                                    if (voroudi23 == 2) {
                                        Lebas lebas = new Lebas(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                                voroudi13, voroudi14, voroudi24, NoeLebas.SHALVAR);
                                        Modir.getAfzoodaneKala(lebas);
                                        k = false;
                                        f = false;
                                    }
                                    if (voroudi23 == 3) {
                                        Lebas lebas = new Lebas(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                                voroudi13, voroudi14, voroudi24, NoeLebas.PIRHAN);
                                        Modir.getAfzoodaneKala(lebas);
                                        k = false;
                                        f = false;
                                    }
                                }
                                if (voroudi20.compareTo("2") == 0) {
                                    System.out.println("saiz?");
                                    voroudi24 = sc.nextInt();
                                    System.out.println("1.BOOT       2.MAJLESI       3.SPORT");
                                    voroudi23 = sc.nextInt();
                                    if (voroudi23 == 1) {
                                        Kafsh kafsh = new Kafsh(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                                voroudi13, voroudi14, voroudi24, NoeKafsh.BOOT);
                                        Modir.getAfzoodaneKala(kafsh);
                                        k = false;
                                        f = false;
                                        ab1 = false;
                                    }
                                    if (voroudi23 == 2) {
                                        Kafsh kafsh = new Kafsh(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                                voroudi13, voroudi14, voroudi24, NoeKafsh.MAJLESI);
                                        Modir.getAfzoodaneKala(kafsh);
                                        f = false;
                                        k = false;
                                        ab1 = false;
                                    }
                                    if (voroudi23 == 3) {
                                        Kafsh kafsh = new Kafsh(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                                voroudi13, voroudi14, voroudi24, NoeKafsh.SPORT);
                                        Modir.getAfzoodaneKala(kafsh);
                                        f = false;
                                        k = false;
                                        ab1 = false;
                                    }
                                }
                                ab1=false;
                            }
                        }
                        if (voroudi12.compareTo("3") == 0) {
                            System.out.println("darajeMasrafeEnergy;?");
                            voroudi13 = sc.next();
                            System.out.println("garanty?    1.darad     2.nadarad");
                            voroudi14 = sc.next();
                            if (voroudi14.compareTo("1") == 0) {
                                ab2 = true;
                            }
                            if (voroudi14.compareTo("2") == 0) {
                                ab2 = false;
                            }
                            System.out.println("1.telvesion     2.yakhchal      3.gaz?");
                            voroudi20 = sc.next();
                            if (voroudi20.compareTo("1") == 0) {
                                System.out.println("keifiat tasvir?");
                                voroudi15 = sc.next();
                                System.out.println("size safhe namayesh?");
                                voroudi26 = sc.nextDouble();
                                Telvesion telvesion = new Telvesion(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                        voroudi13, ab2, voroudi15, voroudi26);
                                k = false;
                                Modir.getAfzoodaneKala(telvesion);
                            }
                            if (voroudi20.compareTo("2") == 0) {
                                System.out.println("noe yakhchal?");
                                voroudi18 = sc.next();
                                System.out.println("gonjayesh?");
                                voroudi26 = sc.nextDouble();
                                System.out.println("Fereizer?       1.darad     2.nadarad");
                                voroudi19 = sc.next();
                                if (voroudi19.compareTo("1") == 0) {
                                    ab3 = true;
                                }
                                if (voroudi19.compareTo("2") == 0) {
                                    ab3 = false;
                                }
                                Yakhchal yakhchal = new Yakhchal(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                        voroudi13, ab2, voroudi18, voroudi26, ab3);
                                k = false;
                                Modir.getAfzoodaneKala(yakhchal);
                            }
                            if (voroudi20.compareTo("3") == 0) {
                                System.out.println("tedad shole?");
                                voroudi25 = sc.nextInt();
                                System.out.println("jens?");
                                voroudi18 = sc.next();
                                System.out.println("fer?       1.darad     2.nadarad");
                                voroudi19 = sc.next();
                                if (voroudi19.compareTo("1") == 0) {
                                    ab3 = true;
                                }
                                if (voroudi19.compareTo("2") == 0) {
                                    ab3 = false;
                                }
                                Gaz gaz = new Gaz(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                        voroudi13, ab2, voroudi25, voroudi18, ab3);
                                k = false;
                                Modir.getAfzoodaneKala(gaz);
                            }
                            f = false;
                        }
                        if (voroudi12.compareTo("4") == 0) {
                            System.out.println("tarikh tolid?");
                            voroudi19 = sc.next();
                            System.out.println("tarikh engheza?");
                            voroudi18 = sc.next();
                            Khoraki khoraki = new Khoraki(voroudi3, voroudi4, voroudi6, voroudi7, voroudi9, voroudi10,
                                    voroudi19, voroudi18);
                            k = false;
                            Modir.getAfzoodaneKala(khoraki);
                            f = false;
                        }
                    }
                }
            } else {
                System.out.println("shoma foroushande nistid!");
            }
        }
    }
}
abstract class HazfeMahsoul{
    public static void hazfeMahsoul(int i){
        Scanner sc=new Scanner(System.in);
        System.out.println("name mahsoul ra vared konid : ");
        String nameKala=sc.next();
        for (int k=0;k<Kala.kolleKalaHa.size();k++){
            if (Kala.kolleKalaHa.get(k).getForooshande()==
                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(i)){
                if (Kala.kolleKalaHa.get(k).getEsm().compareTo(nameKala)==0){
                    Kala.kolleKalaHa.get(k).setVaziateTaeideEzafeShodan(false);
                    Kala.kolleKalaHa.get(k).setShenaseKala(-1);
                }
            }
        }
    }
}
abstract class BarresiNazar{
    public static void barresiNazar(int i){
        Scanner sc=new Scanner(System.in);
        System.out.println("liste nazarate taeid nashode : ");
        for (int k=0;k<Nazar.nazars.size();k++){
            if (Nazar.nazars.get(k).getVaziateNazar()==VaziateNazar.DAR_ENTEZARE_TAEID){
                System.out.println(Nazar.nazars.get(k).toString());
            }
        }
        System.out.println("shomare nazare taeidi ra vared konid : ");
        int shomare=sc.nextInt();
        for (int k=0;k<Nazar.nazars.size();k++){
            if (Nazar.nazars.get(k).getShomareNazar()==shomare){
                Nazar.nazars.get(k).setVaziateNazar(VaziateNazar.TAEID_SHODE);
            }
        }
        System.out.println("shomare nazare taeid nashode ra vared konid : ");
        shomare=sc.nextInt();
        for (int k=0;k<Nazar.nazars.size();k++){
            if (Nazar.nazars.get(k).getShomareNazar()==shomare){
                Nazar.nazars.get(k).setVaziateNazar(VaziateNazar.TAEID_NASHODE);
            }
        }
    }
}
abstract class NomreDahi{
    static void nomreDahi(int i){
        Scanner sc=new Scanner(System.in);
        System.out.println("sabegheye kharid:");
        for (int j=0;j<HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().size();j++){
            System.out.println(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(j).toString());
        }
        System.out.println("name mahsoule morede nazar ra vared konid:");
        String esm=sc.next();
        int neshan=-1;
        for (int j=0;j<HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().size();j++){
            if (esm.compareTo(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(j).getEsm())==0){
                neshan=j;
            }
        }
        if (neshan==-1){
            System.out.println("name eshtebahi vared kardid!");
        }
        else {
            Nomre nomre=new Nomre();

            System.out.println("nomreye khod ra beine 0 ta 5 vared konid!");
            nomre.setEmtiaz(sc.nextDouble());
            nomre.setKarbareNomreDahand(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i));
            nomre.setKala(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan));

            HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan).setTedadNazarat(
                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan).getTedadNazarat()+1);

            HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan).getListeNomarat().add(nomre.getEmtiaz());
            double jameNomarateKarbaran=0;
            for (int k=0;k<HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan).getListeNomarat().size();k++){
                jameNomarateKarbaran=jameNomarateKarbaran+
                        HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan).getListeNomarat().get(k);
            }
            HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan).setMiangineNomreKharidaran(
                    jameNomarateKarbaran/(HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).getSabegheKharid().get(neshan).getTedadNazarat())
            );
        }
    }
}
abstract class NemayeshKalaha{
    static void nemayeshHameKalaHa(){
        for (int i=0;i<Kala.kolleKalaHa.size();i++){
            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.RAD)
            {
                System.out.println(Kala.kolleKalaHa.get(i).toString());
            }
        }
        boolean b=true;
        while (b) {
            System.out.println("tamayol be serch ba filter?     1.bale     2.kheir");
            Scanner sc=new Scanner(System.in);
            String voroudi1=sc.next();
            if(voroudi1.compareTo("1")==0){
                boolean c=true;
                while (c){

                    int size=Kala.kolleKalaHa.size();
                    Kala[] kalaHaSortShode=new Kala[size];
                    for (int i=0;i<size;i++){
                        if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan()){
                            kalaHaSortShode[i]=Kala.kolleKalaHa.get(i);
                        }
                    }
                    for(int i=0;i<size-1;i++){
                        for(int j=i+1;j<size;j++){
                            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan()){
                                if (Kala.kolleKalaHa.get(j).isVaziateTaeideEzafeShodan()){
                                    if (kalaHaSortShode[j].compareTo(kalaHaSortShode[i])==1) {
                                        Kala temp;
                                        temp = kalaHaSortShode[j];
                                        kalaHaSortShode[j] = kalaHaSortShode[i];
                                        kalaHaSortShode[i] = temp;
                                    }
                                }
                            }
                        }
                    }
                    for(int i=0;i<kalaHaSortShode.length;i++){
                        if (kalaHaSortShode[i].isVaziateTaeideEzafeShodan() && kalaHaSortShode[i]!=null){
                            System.out.println(kalaHaSortShode[i].toString());
                        }
                    }
                    c=false;
                }
                b=false;
            }
            if(voroudi1.compareTo("2")==0){
                b=false;
            }
        }
    }
    static void nemayeshKalahayeDigital(){
        for (int i=0;i<KalayeDigital.kolleKalaHa.size();i++){
            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.RAD){
                System.out.println(KalayeDigital.kolleKalaHa.get(i).toString());

            }
        }
        boolean b=true;
        while (b) {
            System.out.println("tamayol be serch ba filter?     1.bale     2.kheir");
            Scanner sc=new Scanner(System.in);
            String voroudi1=sc.next();
            if(voroudi1.compareTo("1")==0){
                boolean c=true;
                while (c){

                    int size=Kala.kolleKalaHa.size();
                    Kala[] kalaHaSortShode=new Kala[size];
                    for (int i=0;i<size;i++){
                        if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                                Kala.kolleKalaHa.get(i) instanceof KalayeDigital){
                            kalaHaSortShode[i]=Kala.kolleKalaHa.get(i);
                        }
                    }
                    for(int i=0;i<size-1;i++){
                        for(int j=i+1;j<size;j++){
                            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan()){
                                if (Kala.kolleKalaHa.get(j).isVaziateTaeideEzafeShodan()){
                                    if (kalaHaSortShode[j].compareTo(kalaHaSortShode[i])==1) {
                                        Kala temp;
                                        temp = kalaHaSortShode[j];
                                        kalaHaSortShode[j] = kalaHaSortShode[i];
                                        kalaHaSortShode[i] = temp;
                                    }
                                }
                            }
                        }
                    }
                    for(int i=0;i<kalaHaSortShode.length;i++){
                        if (kalaHaSortShode[i].isVaziateTaeideEzafeShodan() && kalaHaSortShode[i]!=null){
                            System.out.println(kalaHaSortShode[i].toString());
                        }
                    }
                    c=false;
                }
                b=false;
            }
            if(voroudi1.compareTo("2")==0){
                b=false;
            }
        }
    }
    static void nemayeshPooshak(){
        for (int i=0;i<Pooshak.kolleKalaHa.size();i++){
            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.RAD) {
                System.out.println(Pooshak.kolleKalaHa.get(i).toString());

            }
        }
        boolean b=true;
        while (b) {
            System.out.println("tamayol be serch ba filter?     1.bale     2.kheir");
            Scanner sc=new Scanner(System.in);
            String voroudi1=sc.next();
            if(voroudi1.compareTo("1")==0){
                boolean c=true;
                while (c){

                    int size=Kala.kolleKalaHa.size();
                    Kala[] kalaHaSortShode=new Kala[size];
                    for (int i=0;i<size;i++){
                        if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                                Kala.kolleKalaHa.get(i) instanceof Pooshak){
                            kalaHaSortShode[i]=Kala.kolleKalaHa.get(i);
                        }
                    }
                    for(int i=0;i<size-1;i++){
                        for(int j=i+1;j<size;j++){
                            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan()){
                                if (Kala.kolleKalaHa.get(j).isVaziateTaeideEzafeShodan()){
                                    if (kalaHaSortShode[j].compareTo(kalaHaSortShode[i])==1) {
                                        Kala temp;
                                        temp = kalaHaSortShode[j];
                                        kalaHaSortShode[j] = kalaHaSortShode[i];
                                        kalaHaSortShode[i] = temp;
                                    }
                                }
                            }
                        }
                    }
                    for(int i=0;i<kalaHaSortShode.length;i++){
                        if (kalaHaSortShode[i].isVaziateTaeideEzafeShodan() && kalaHaSortShode[i]!=null){
                            System.out.println(kalaHaSortShode[i].toString());
                        }
                    }
                    c=false;
                }
                b=false;
            }
            if(voroudi1.compareTo("2")==0){
                b=false;
            }
        }
    }
    static void nemayeshLavazemeKhanegi(){
        for (int i=0;i<LavazemKhanegi.kolleKalaHa.size();i++){
            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.RAD) {
                System.out.println(LavazemKhanegi.kolleKalaHa.get(i).toString());

            }
        }
        boolean b=true;
        while (b) {
            System.out.println("tamayol be serch ba filter?     1.bale     2.kheir");
            Scanner sc=new Scanner(System.in);
            String voroudi1=sc.next();
            if(voroudi1.compareTo("1")==0){
                boolean c=true;
                while (c){

                    int size=Kala.kolleKalaHa.size();
                    Kala[] kalaHaSortShode=new Kala[size];
                    for (int i=0;i<size;i++){
                        if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                                Kala.kolleKalaHa.get(i) instanceof LavazemKhanegi){
                            kalaHaSortShode[i]=Kala.kolleKalaHa.get(i);
                        }
                    }
                    for(int i=0;i<size-1;i++){
                        for(int j=i+1;j<size;j++){
                            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan()){
                                if (Kala.kolleKalaHa.get(j).isVaziateTaeideEzafeShodan()){
                                    if (kalaHaSortShode[j].compareTo(kalaHaSortShode[i])==1) {
                                        Kala temp;
                                        temp = kalaHaSortShode[j];
                                        kalaHaSortShode[j] = kalaHaSortShode[i];
                                        kalaHaSortShode[i] = temp;
                                    }
                                }
                            }
                        }
                    }
                    for(int i=0;i<kalaHaSortShode.length;i++){
                        if (kalaHaSortShode[i].isVaziateTaeideEzafeShodan() && kalaHaSortShode[i]!=null){
                            System.out.println(kalaHaSortShode[i].toString());
                        }
                    }
                    c=false;
                }
                b=false;
            }
            if(voroudi1.compareTo("2")==0){
                b=false;
            }
        }
    }
    static void nemayeshKhorakiha(){
        for (int i=0;i<Khoraki.kolleKalaHa.size();i++){
            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.DAR_ENTEZAR &&
                    Kala.kolleKalaHa.get(i).getVaziateDarkhasteTaghireEtteleat()!=VaziateDarkhasteTaghireEtteleat.RAD) {
                System.out.println(Khoraki.kolleKalaHa.get(i).toString());

            }
        }
        boolean b=true;
        while (b) {
            System.out.println("tamayol be serch ba filter?     1.bale     2.kheir");
            Scanner sc=new Scanner(System.in);
            String voroudi1=sc.next();
            if(voroudi1.compareTo("1")==0){
                boolean c=true;
                while (c){

                    int size=Kala.kolleKalaHa.size();
                    Kala[] kalaHaSortShode=new Kala[size];
                    for (int i=0;i<size;i++){
                        if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan() &&
                                Kala.kolleKalaHa.get(i) instanceof Khoraki){
                            kalaHaSortShode[i]=Kala.kolleKalaHa.get(i);
                        }
                    }
                    for(int i=0;i<size-1;i++){
                        for(int j=i+1;j<size;j++){
                            if (Kala.kolleKalaHa.get(i).isVaziateTaeideEzafeShodan()){
                                if (Kala.kolleKalaHa.get(j).isVaziateTaeideEzafeShodan()){
                                    if (kalaHaSortShode[j].compareTo(kalaHaSortShode[i])==1) {
                                        Kala temp;
                                        temp = kalaHaSortShode[j];
                                        kalaHaSortShode[j] = kalaHaSortShode[i];
                                        kalaHaSortShode[i] = temp;
                                    }
                                }
                            }
                        }
                    }
                    for(int i=0;i<kalaHaSortShode.length;i++){
                        if (kalaHaSortShode[i].isVaziateTaeideEzafeShodan() && kalaHaSortShode[i]!=null){
                            System.out.println(kalaHaSortShode[i].toString());
                        }
                    }
                    c=false;
                }
                b=false;
            }
            if(voroudi1.compareTo("2")==0){
                b=false;
            }
        }
    }
}
abstract class MoshahedeSabadeKharid{
    static void moshahedeSabadeKharid() throws AdamMojoudiEtebar, AdamMojoudiKala {
        int neshan=0;
        for (int i=0;i<HesabKarbari.getHesabKarbariHayeSakhteShode().size();i++){
            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(i).isLogin()){
                neshan=i;
                i=HesabKarbari.getHesabKarbariHayeSakhteShode().size();
            }
        }
        for (int i=0;i<HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().size();i++){
            System.out.println(HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(i).toString());
        }
        if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().size()==0){
            try {
                throw new AdamMojoudiKala();
            }
            catch (AdamMojoudiKala ad){
                System.out.println(ad.toString());
            }
            //System.out.println("sabade kharid khali ast!");
        }
        else {
            boolean g=true;
            while (g){
                System.out.println("********************************");
                System.out.println("1.jahate taeid");
                System.out.println("2.jahate khorouj");
                Scanner sc=new Scanner(System.in);
                String voroudi1=sc.next();
                if (voroudi1.compareTo("1")==0){
                    double jameFactoreKharid=0.0;
                    for (int j=0;j<HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid()
                            .size();j++){
                        jameFactoreKharid=jameFactoreKharid+ HesabKarbari.getHesabKarbariHayeSakhteShode()
                                .get(neshan).getSabadeKharid().get(j).getGheimat();
                    }
                    if (HesabKarbari.getHesabKarbariHayeSakhteShode()
                            .get(neshan).getEtebar()>=jameFactoreKharid){
                        System.out.println("kharid anjam shod!");
                        for (int j=0;j<HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid()
                                .size();j++){
                            HesabKarbari.getHesabKarbariHayeSakhteShode()
                                    .get(neshan).getSabegheKharid().add(
                                            HesabKarbari.getHesabKarbariHayeSakhteShode()
                                                    .get(neshan).getSabadeKharid().get(j));
                        }
                        HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).setEtebar(
                                HesabKarbari.getHesabKarbariHayeSakhteShode().
                                        get(neshan).getEtebar()-jameFactoreKharid
                        );
                        System.out.println("tarikh?");
                        String tarikh=sc.next();

                        FactoreKharid factoreKharid=new FactoreKharid(tarikh,jameFactoreKharid,false);
                        for (int k=0;k<HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().size();k++){
                            factoreKharid.getKalas().add(HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(k));
                        }

                        for (int k=0;k<HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().size();k++){
                            FactoreForoosh factoreForoosh=new FactoreForoosh(tarikh,
                                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(k).getGheimat(),
                                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getNam());

                            HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(k).getForooshande().setEtebar(
                                    (HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(k).getForooshande().getEtebar())+
                                            (HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(k).getGheimat()));

                            HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabegheKharid().add(
                                    HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(k)
                            );

                            factoreForoosh.getKalaHa().add( HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().get(k));
                        }
                        HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getFactoreKharids().add(factoreKharid);

                        HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan).getSabadeKharid().clear();

                        g=false;
                    }
                    else {
                        try {
                            throw new AdamMojoudiEtebar();
                        }
                        catch (AdamMojoudiEtebar ad){
                            System.out.println(ad.toString());
                        }
                        finally {
                            System.out.println("movaffagh bashid !");
                        }
                        //System.out.println("adame mojoudi!");
                    }
                    g=false;
                }
                if (voroudi1.compareTo("2")==0){
                    g=false;
                }
            }
        }
    }
}
abstract class SafheyeMahsoulat {
    static void safheyeMahsoulat() throws AdamMojoudiEtebar, AdamMojoudiKala, TelephoneNaMotabar, IOException {
        boolean a = true;
        while (a) {
            System.out.println("1.moshahede hameye kalaha    2.moshahedeye kalahaye digital");
            System.out.println("3.moshahede pooshak          4.moshahedeye lavazeme khanegi");
            System.out.println("5.moshahede khorakiha        6.sabte nazar");
            System.out.println("7.khorouj");
            Scanner sc = new Scanner(System.in);
            String voroudi1 = sc.next();
            String voroudi2;
            String voroudi3;
            if (voroudi1.compareTo("1") == 0) {
                NemayeshKalaha.nemayeshHameKalaHa();
            }
            if (voroudi1.compareTo("2") == 0) {
                NemayeshKalaha.nemayeshKalahayeDigital();
            }
            if (voroudi1.compareTo("3") == 0) {
                NemayeshKalaha.nemayeshPooshak();
            }
            if (voroudi1.compareTo("4") == 0) {
                NemayeshKalaha.nemayeshLavazemeKhanegi();
            }
            if (voroudi1.compareTo("5") == 0) {
                NemayeshKalaha.nemayeshKhorakiha();
            }
            if (voroudi1.compareTo("6") == 0) {
                SabteNazar.sabteNazar();
            }
            if (voroudi1.compareTo("7") == 0) {
                a = false;
            }
            if (voroudi1.compareTo("1") == 0 ||
                    voroudi1.compareTo("2") == 0 ||
                    voroudi1.compareTo("3") == 0 ||
                    voroudi1.compareTo("4") == 0 ||
                    voroudi1.compareTo("5") == 0) {
                boolean c = true;
                while (c) {
                    System.out.println("tamayol be kharid?      1.bale      2.kheir");
                    voroudi2 = sc.next();
                    if (voroudi2.compareTo("1") == 0) {
                        boolean neshan1 = false;
                        int neshan2 = 0;
                        for (int j = 0; j < HesabKarbari.getHesabKarbariHayeSakhteShode().size() ; j++) {
                            if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(j).isLogin()) {
                                neshan1 = true;
                                neshan2 = j;
                                j = HesabKarbari.getHesabKarbariHayeSakhteShode().size();
                            }
                        }
                        if (neshan1) {
                            boolean e = true;
                            while (e) {
                                System.out.println("jahate kharid esme kalaye morede nazar ra daghigh vared konid:");
                                voroudi3 = sc.next();
                                int neshan3 = 0;
                                for (int k = 0; k < Kala.kolleKalaHa.size(); k++) {
                                    if (voroudi3.compareTo(Kala.kolleKalaHa.get(k).getEsm()) == 0) {
                                        neshan3 = 1;
                                        System.out.println("kalaye morede nazar yaft shod!");
                                        HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan2).getSabadeKharid()
                                                .add(Kala.kolleKalaHa.get(k));
                                        System.out.println("mahsoul ba movaffaghiiat be sabade kharid ezafe shod!");
                                        k = Kala.kolleKalaHa.size();
                                        e=false;
                                    }
                                }
                                if (neshan3 == 0) {
                                    boolean f = true;
                                    while (f) {
                                        System.out.println("kalaye morede nazar yaft nashod!");
                                        System.out.println("1.jahate serche mojaddad ");
                                        System.out.println("2.jahate khorouj ");
                                        voroudi3 = sc.next();
                                        if (voroudi3.compareTo("1") == 0) {
                                            f = false;
                                        }
                                        if (voroudi3.compareTo("2") == 0) {
                                            f = false;
                                            e = false;
                                        }
                                    }
                                }
                            }
                        } else {
                            boolean d = true;
                            while (d) {
                                System.out.println("shoma lagin nistin.");
                                System.out.println("1.raftan be safheye lagin");
                                System.out.println("2.sabte nam va sakhte hesab");
                                System.out.println("3.khorouj");
                                voroudi3 = sc.next();
                                if (voroudi3.compareTo("1") == 0) {
                                    Lagin.lagin();
                                    d = false;
                                }
                                if (voroudi3.compareTo("2") == 0) {
                                    SabteNam.sabteNam();
                                    d = false;
                                }
                                if (voroudi3.compareTo("3") == 0) {
                                    d = false;
                                }
                            }
                        }
                        c = false;
                    }
                    if (voroudi2.compareTo("2") == 0) {
                        c = false;
                    }
                }
            }
        }
    }
}
abstract class SabteNazar{
    static void sabteNazar(){
        System.out.println("name kala ra vared konid:");
        Scanner sc=new Scanner(System.in);
        String nameKala=sc.next();
        int neshan3=-1;
        for (int k=0;k<Kala.kolleKalaHa.size();k++){
            if (Kala.kolleKalaHa.get(k).getEsm().compareTo(nameKala)==0){
                neshan3=k;
            }
        }
        if (neshan3==-1){
            System.out.println("kalayi ba name voroudi yaft nashod!");
        }
        else {
            int neshan4=-1;
            for (int k=0;k<HesabKarbari.getHesabKarbariHayeSakhteShode().size();k++){
                if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(k).isLogin()){
                    neshan4=k;
                }
            }
            if (neshan4==-1){
                System.out.println("shoma lagin nistin va in ghabeliat ra nadarid!");
            }
            else {
                int neshan=-1;
                for (int l=0;l<HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan4).
                        getSabegheKharid().size();l++){
                    if (HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan4).
                            getSabegheKharid().get(l).getEsm().compareTo(nameKala)==0){
                        neshan=l;
                    }
                }

                System.out.println("nazare khod ra vared konid:");
                Nazar nazar=new Nazar();
                if (neshan==-1){
                    nazar.setAyaNazarDahandeKharidKarde(false);
                }
                else {
                    nazar.setAyaNazarDahandeKharidKarde(true);
                }
                nazar.setMatneNazar(sc.next());
                nazar.setKarbareNazarDahande(HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan4));
                nazar.setKala(Kala.kolleKalaHa.get(neshan3));
                nazar.setVaziateNazar(VaziateNazar.DAR_ENTEZARE_TAEID);
                Kala.kolleKalaHa.get(neshan3).getListeNazarat().add(nazar);
                Kala.kolleKalaHa.get(neshan3).setTedadNazarat(Kala.kolleKalaHa.get(neshan3).getTedadNazarat()+1);
                Kala.kolleKalaHa.get(neshan3).getListeIdeAfradeNazarDahande().add(neshan4);
                int neshan5=-1;
                for (int k=0;k<HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan4).getSabegheKharid().size();k++){
                    if(HesabKarbari.getHesabKarbariHayeSakhteShode().get(neshan4).getSabegheKharid().get(k)==Kala.kolleKalaHa.get(neshan3)){
                        neshan5=0;
                    }
                }
                if (neshan5==-1){
                    Kala.kolleKalaHa.get(neshan3).getListeTaeidEKharideAfradeNazarDahande().add(false);
                }
                else {
                    Kala.kolleKalaHa.get(neshan3).getListeTaeidEKharideAfradeNazarDahande().add(true);
                }
            }
        }
    }
}
//--------------------------------------------------
class FactoreKharid{
    private int shenaseFactor;
    private String tarikh;
    private double mablaghePardakhtShode;
    private ArrayList<Kala> kalaHa=new ArrayList<>();
    private String nameForooshande;
    private boolean vaziateTahvil=false;
    public static int shenase=0;

    public static ArrayList<FactoreKharid> factoreKharids=new ArrayList<>();
    public FactoreKharid(){
        factoreKharids.add(this);
        this.shenaseFactor = shenase;
        shenase++;
    }

    public FactoreKharid( String tarikh, double mablaghePardakhtShode, boolean vaziateTahvil) {
        this.shenaseFactor = shenase;
        shenase++;
        this.tarikh = tarikh;
        this.mablaghePardakhtShode = mablaghePardakhtShode;
        this.vaziateTahvil = vaziateTahvil;
        factoreKharids.add(this);
    }

    public int getShenaseFactor() {
        return shenaseFactor;
    }
    public void setShenaseFactor(int shenaseFactor) {
        this.shenaseFactor = shenaseFactor;
    }
    public String getTarikh() {
        return tarikh;
    }
    public void setTarikh(String tarikh) {
        this.tarikh = tarikh;
    }
    public double getMablaghePardakhtShode() {
        return mablaghePardakhtShode;
    }
    public void setMablaghePardakhtShode(double mablaghePardakhtShode) {
        this.mablaghePardakhtShode = mablaghePardakhtShode;
    }
    public ArrayList<Kala> getKalas() {
        return kalaHa;
    }
    public void setKalas(ArrayList<Kala> kalas) {
        this.kalaHa = kalas;
    }
    public String getNameForooshande() {
        return nameForooshande;
    }
    public void setNameForooshande(String nameForooshande) {
        this.nameForooshande = nameForooshande;
    }
    public boolean isVaziateTahvil() {
        return vaziateTahvil;
    }
    public void setVaziateTahvil(boolean vaziateTahvil) {
        this.vaziateTahvil = vaziateTahvil;
    }

}
class FactoreForoosh{
    private int shenaseFactor;
    private String tarikh;
    private double mablagheDaryaftShode;
    private ArrayList<Kala> kalaHa=new ArrayList<>();
    private String nameKharidar;
    private boolean vaziateErsal=false;
    public static int shenase=0;

    public static ArrayList<FactoreForoosh> factoreForooshes=new ArrayList<>();
    public FactoreForoosh(String tarikh, double mablagheDaryaftShode,
                          String nameKharidar) {
        this.shenaseFactor = shenase;
        shenase++;
        this.tarikh = tarikh;
        this.mablagheDaryaftShode = mablagheDaryaftShode;
        this.nameKharidar = nameKharidar;
        factoreForooshes.add(this);
    }
    public FactoreForoosh(){
        this.shenaseFactor = shenase;
        shenase++;
        factoreForooshes.add(this);
    }

    public int getShenaseFactor() {
        return shenaseFactor;
    }
    public void setShenaseFactor(int shenaseFactor) {
        this.shenaseFactor = shenaseFactor;
    }
    public String getTarikh() {
        return tarikh;
    }
    public void setTarikh(String tarikh) {
        this.tarikh = tarikh;
    }
    public double getMablagheDaryaftShode() {
        return mablagheDaryaftShode;
    }
    public void setMablagheDaryaftShode(double mablagheDaryaftShode) {
        this.mablagheDaryaftShode = mablagheDaryaftShode;
    }
    public ArrayList<Kala> getKalaHa() {
        return kalaHa;
    }
    public void setKalaHa(ArrayList<Kala> kalaHa) {
        this.kalaHa = kalaHa;
    }
    public String getNameKharidar() {
        return nameKharidar;
    }
    public void setNameKharidar(String nameKharidar) {
        this.nameKharidar = nameKharidar;
    }
    public boolean isVaziateErsal() {
        return vaziateErsal;
    }
    public void setVaziateErsal(boolean vaziateErsal) {
        this.vaziateErsal = vaziateErsal;
    }
    public static int getShenase() {
        return shenase;
    }
    public static void setShenase(int shenase) {
        FactoreForoosh.shenase = shenase;
    }

}
class Nomre {
    private HesabKarbari karbareNomreDahand;
    private double emtiaz;
    private Kala kala;

    public Nomre(){}

    public HesabKarbari getKarbareNomreDahand() {
        return karbareNomreDahand;
    }
    public void setKarbareNomreDahand(HesabKarbari karbareNomreDahand) {
        this.karbareNomreDahand = karbareNomreDahand;
    }
    public double getEmtiaz() {
        return emtiaz;
    }
    public void setEmtiaz(double emtiaz) {
        this.emtiaz = emtiaz;
    }
    public Kala getKala() {
        return kala;
    }
    public void setKala(Kala kala) {
        this.kala = kala;
    }
}
class Nazar{
    public static int shomareNazarat=0;
    private int shomareNazar;
    private HesabKarbari karbareNazarDahande;
    private Kala kala;
    private String matneNazar;
    private VaziateNazar vaziateNazar=VaziateNazar.DAR_ENTEZARE_TAEID;
    private boolean ayaNazarDahandeKharidKarde;

    static ArrayList<Nazar> nazars=new ArrayList<>();

    public Nazar(){
        nazars.add(this);
        this.shomareNazar=shomareNazarat;
        shomareNazarat++;
    }

    @Override
    public String toString(){
        int x=0;
        if (ayaNazarDahandeKharidKarde){
            return "\nnazar dahande : "+this.karbareNazarDahande +
                    "\nkala : "+this.kala+
                    "\nmatneNazar : "+this.matneNazar+
                    "\nvaziateNazar : "+this.vaziateNazar+
                    "\nayaNazarDahandeKharidKarde ? : bale"+
                    "\nshomareNazar : "+this.shomareNazar+"\n";
        }
        else {
            return "\n nazar dahande : "+this.karbareNazarDahande+
                    "\nkala : "+this.kala+
                    "\nmatneNazar : "+this.matneNazar+
                    "\nvaziateNazar : "+this.vaziateNazar+
                    "\nayaNazarDahandeKharidKarde ? : kheir"+
                    "\nshomareNazar : "+this.shomareNazar+"\n";
        }
    }

    public static int getShomareNazarat() {
        return shomareNazarat;
    }
    public static void setShomareNazarat(int shomareNazarat) {
        Nazar.shomareNazarat = shomareNazarat;
    }
    public int getShomareNazar() {
        return shomareNazar;
    }
    public void setShomareNazar(int shomareNazar) {
        this.shomareNazar = shomareNazar;
    }
    public static ArrayList<Nazar> getNazars() {
        return nazars;
    }
    public static void setNazars(ArrayList<Nazar> nazars) {
        Nazar.nazars = nazars;
    }
    public HesabKarbari getKarbareNazarDahande() {
        return karbareNazarDahande;
    }
    public void setKarbareNazarDahande(HesabKarbari karbareNazarDahande) {
        this.karbareNazarDahande = karbareNazarDahande;
    }
    public Kala getKala() {
        return kala;
    }
    public void setKala(Kala kala) {
        this.kala = kala;
    }
    public String getMatneNazar() {
        return matneNazar;
    }
    public void setMatneNazar(String matneNazar) {
        this.matneNazar = matneNazar;
    }
    public VaziateNazar getVaziateNazar() {
        return vaziateNazar;
    }
    public void setVaziateNazar(VaziateNazar vaziateNazar) {
        this.vaziateNazar = vaziateNazar;
    }
    public boolean isAyaNazarDahandeKharidKarde() {
        return ayaNazarDahandeKharidKarde;
    }
    public void setAyaNazarDahandeKharidKarde(boolean ayaNazarDahandeKharidKarde) {
        this.ayaNazarDahandeKharidKarde = ayaNazarDahandeKharidKarde;
    }
}
class Daste{
    private String esm;
    private String vizhegiMakhsous;
    private ArrayList<Kala> listeMahsoulat=new ArrayList<>();

    public Daste(String esm,String vizhegiMakhsous) {
        this.esm = esm;
        this.vizhegiMakhsous=vizhegiMakhsous;
    }

    public String getEsm() {
        return esm;
    }
    public void setEsm(String esm) {
        this.esm = esm;
    }
    public String getVizhegiMakhsous() {
        return vizhegiMakhsous;
    }
    public void setVizhegiMakhsous(String vizhegiMakhsous) {
        this.vizhegiMakhsous = vizhegiMakhsous;
    }
    public ArrayList<Kala> getListeMahsoulat() {
        return listeMahsoulat;
    }
    public void setListeMahsoulat(ArrayList<Kala> listeMahsoulat) {
        this.listeMahsoulat = listeMahsoulat;
    }
}
//--------------------------------------------------
abstract class HesabKarbari{
    private String nameKarbari;
    private String nam;
    private String nameKhanevadegi;
    private String email;
    private long shomareTelephon;
    private String ramzeOboor;
    private Naghsh naghsh;
    private int idShomarandeSabteNamiHa;
    private double etebar=0.0;
    private boolean login=false;
    private boolean taeideModir=false;
    private boolean faal=false;

    private ArrayList<Kala> sabegheForoosh=new ArrayList<>();
    private ArrayList<Kala> sabegheKharid=new ArrayList<>();
    private ArrayList<Kala> sabadeKharid=new ArrayList<>();
    private ArrayList<FactoreKharid> factoreKharids=new ArrayList<>();
    private ArrayList<FactoreForoosh> factoreForooshes=new ArrayList<>();

    static private ArrayList<HesabKarbari> hesabKarbariHayeSakhteShode=new ArrayList<>();


    public HesabKarbari(String nameKarbari, String nam, String nameKhanevadegi, String email,
                        long shomareTelephon, String ramzeOboor, Naghsh naghsh, int idShomarandeSabteNamiHa,
                        double etebar, boolean login) {
        this.nameKarbari = nameKarbari;
        this.nam = nam;
        this.nameKhanevadegi = nameKhanevadegi;
        this.email = email;
        this.shomareTelephon = shomareTelephon;
        this.ramzeOboor = ramzeOboor;
        this.naghsh = naghsh;
        this.idShomarandeSabteNamiHa = idShomarandeSabteNamiHa;
        this.etebar = etebar;
        this.login = login;
        this.faal=true;
        HesabKarbari.ezafeKardanHesabHayeSakhteShode(this);
    }
    public HesabKarbari(String nameKarbari, String ramzeOboor, Naghsh naghsh) {
        this.nameKarbari = nameKarbari;
        this.ramzeOboor = ramzeOboor;
        this.naghsh = naghsh;
        HesabKarbari.ezafeKardanHesabHayeSakhteShode(this);
    }
    public HesabKarbari(){
        this.faal=true;
    }

    @Override
    public String toString(){
        return   "\n *****************************"+
                "\n name karbari : "+this.nameKarbari+
                "\n nam : "+this.nam+
                "\n name khanevadegi : "+this.nameKhanevadegi+
                "\n email : "+this.email+
                "\n shomareTelephon : "+this.shomareTelephon+
                "\n ramzeOboor : "+this.ramzeOboor+
                "\n naghsh : "+this.naghsh+
                "\n idShomarandeSabteNamiHa : "+this.idShomarandeSabteNamiHa+
                "\n etebar : "+this.etebar+
                "\n *****************************\n";
    }

    public boolean isFaal() {
        return faal;
    }
    public void setFaal(boolean faal) {
        this.faal = faal;
    }
    public ArrayList<FactoreKharid> getFactoreKharids() {
        return factoreKharids;
    }
    public void setFactoreKharids(ArrayList<FactoreKharid> factoreKharids) {
        this.factoreKharids = factoreKharids;
    }
    public ArrayList<FactoreForoosh> getFactoreForooshes() {
        return factoreForooshes;
    }
    public void setFactoreForooshes(ArrayList<FactoreForoosh> factoreForooshes) {
        this.factoreForooshes = factoreForooshes;
    }
    public void setTaeideModir(boolean taeideModir) {
        this.taeideModir = taeideModir;
    }
    public ArrayList<Kala> getSabadeKharid() {
        return sabadeKharid;
    }
    public void setSabadeKharid(ArrayList<Kala> sabadeKharid) {
        this.sabadeKharid = sabadeKharid;
    }
    public boolean isTaeideModir() {
        return taeideModir;
    }
    public boolean isLogin() {
        return login;
    }
    public void setLogin(boolean login) {
        this.login = login;
    }
    public int getIdShomarandeSabteNamiHa() {
        return idShomarandeSabteNamiHa;
    }
    public void setIdShomarandeSabteNamiHa(int idShomarandeSabteNamiHa) {
        this.idShomarandeSabteNamiHa = idShomarandeSabteNamiHa;
    }
    public static void ezafeKardanHesabHayeSakhteShode(HesabKarbari hesabKarbari){
        hesabKarbariHayeSakhteShode.add(hesabKarbari);
    }
    public String getNameKarbari() {
        return nameKarbari;
    }
    public void setNameKarbari(String nameKarbari) {
        this.nameKarbari = nameKarbari;
    }
    public String getNam() {
        return nam;
    }
    public void setNam(String nam) {
        this.nam = nam;
    }
    public String getNameKhanevadegi() {
        return nameKhanevadegi;
    }
    public void setNameKhanevadegi(String nameKhanevadegi) {
        this.nameKhanevadegi = nameKhanevadegi;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public long getShomareTelephon() {
        return shomareTelephon;
    }
    public void setShomareTelephon(long shomareTelephon) {
        this.shomareTelephon = shomareTelephon;
    }
    public String getRamzeOboor() {
        return ramzeOboor;
    }
    public void setRamzeOboor(String ramzeOboor) {
        this.ramzeOboor = ramzeOboor;
    }
    public Naghsh getNaghsh() {
        return naghsh;
    }
    public void setNaghsh(Naghsh naghsh) {
        this.naghsh = naghsh;
    }
    public double getEtebar() {
        return etebar;
    }
    public void setEtebar(double etebar) {
        this.etebar = etebar;
    }
    public static ArrayList<HesabKarbari> getHesabKarbariHayeSakhteShode() {
        return hesabKarbariHayeSakhteShode;
    }
    public static void setHesabKarbariHayeSakhteShode(ArrayList<HesabKarbari> hesabKarbariHayeSakhteShode) {
        HesabKarbari.hesabKarbariHayeSakhteShode = hesabKarbariHayeSakhteShode;
    }
    public ArrayList<Kala> getSabegheForoosh() {
        return sabegheForoosh;
    }
    public ArrayList<Kala> getSabegheKharid() {
        return sabegheKharid;
    }
    public void setSabegheForoosh(ArrayList<Kala> sabegheForoosh) {
        this.sabegheForoosh = sabegheForoosh;
    }
    public void setSabegheKharid(ArrayList<Kala> sabegheKharid) {
        this.sabegheKharid = sabegheKharid;
    }
}
class Modir extends HesabKarbari {
    private static Modir modir;
    static ArrayList<String> darkhastha=new ArrayList<>();
    static ArrayList<Nazar> nazars=new ArrayList<>();
    static ArrayList<Forooshande> virayeshEttelaateForooshandeHa=new ArrayList<>();
    static ArrayList<Kala> afzoodaneKala=new ArrayList<>();

    Modir(String nameKarbari, String ramzeObour){
        super(nameKarbari,ramzeObour,Naghsh.MODIR);
    }
    public Modir(){}
    public static Modir sakhtYekDane(){
        if(modir==null){
            modir=new Modir("admin","admin");
        }
        return modir;
    }

    public static Modir getModir() {
        return modir;
    }
    public static void setModir(Modir modir) {
        Modir.modir = modir;
    }
    public static ArrayList<Nazar> getNazars() {
        return nazars;
    }
    public static void setNazars(ArrayList<Nazar> nazars) {
        Modir.nazars = nazars;
    }
    public static ArrayList<Forooshande> getVirayeshEttelaateForooshandeHa() {
        return virayeshEttelaateForooshandeHa;
    }
    public static void setVirayeshEttelaateForooshandeHa(ArrayList<Forooshande> virayeshEttelaateForooshandeHa) {
        Modir.virayeshEttelaateForooshandeHa = virayeshEttelaateForooshandeHa;
    }
    public static ArrayList<Kala> getAfzoodaneKala(Kala mobile) {
        return afzoodaneKala;
    }
    public static void setAfzoodaneKala(ArrayList<Kala> afzoodaneKala) {
        Modir.afzoodaneKala = afzoodaneKala;
    }
    public static ArrayList<String> getDarkhastha() {
        return darkhastha;
    }
    public static void setDarkhastha(ArrayList<String> darkhastha) {
        Modir.darkhastha = darkhastha;
    }
    static public void barresiDarkhastHa(HesabKarbari hesabKarbari){
    }
}
class Forooshande extends HesabKarbari {
    private String  esmeSherkat;
    private String  esmeKargah;
    private String  esmeKarkhane;
    private ArrayList<Kala> kalas=new ArrayList<>();
    private ArrayList<Kala> sabegheForoosh=new ArrayList<>();
    private ArrayList<Kala> listeMahsoulateForooshi=new ArrayList<>();

    public Forooshande(){}

    public ArrayList<Kala> getKalas() {
        return kalas;
    }
    public void setKalas(ArrayList<Kala> kalas) {
        this.kalas = kalas;
    }
    public String getEsmeSherkat() {
        return esmeSherkat;
    }
    public void setEsmeSherkat(String esmeSherkat) {
        this.esmeSherkat = esmeSherkat;
    }
    public String getEsmeKargah() {
        return esmeKargah;
    }
    public void setEsmeKargah(String esmeKargah) {
        this.esmeKargah = esmeKargah;
    }
    public String getEsmeKarkhane() {
        return esmeKarkhane;
    }
    public void setEsmeKarkhane(String esmeKarkhane) {
        this.esmeKarkhane = esmeKarkhane;
    }
    @Override
    public ArrayList<Kala> getSabegheForoosh() {
        return sabegheForoosh;
    }
    @Override
    public void setSabegheForoosh(ArrayList<Kala> sabegheForoosh) {
        this.sabegheForoosh = sabegheForoosh;
    }
    public ArrayList<Kala> getListeMahsoulateForooshi() {
        return listeMahsoulateForooshi;
    }
    public void setListeMahsoulateForooshi(ArrayList<Kala> listeMahsoulateForooshi) {
        this.listeMahsoulateForooshi = listeMahsoulateForooshi;
    }
}
class Kharidar extends HesabKarbari{
    private ArrayList<Kala> sabadeKharid=new ArrayList<>();
    private ArrayList<Kala> sabegheKharid=new ArrayList<>();

    public Kharidar(){}

    @Override
    public ArrayList<Kala> getSabadeKharid() {
        return sabadeKharid;
    }
    @Override
    public void setSabadeKharid(ArrayList<Kala> sabadeKharid) {
        this.sabadeKharid = sabadeKharid;
    }
    @Override
    public ArrayList<Kala> getSabegheKharid() {
        return sabegheKharid;
    }
    @Override
    public void setSabegheKharid(ArrayList<Kala> sabegheKharid) {
        this.sabegheKharid = sabegheKharid;
    }
}
//--------------------------------------------------
class Kala implements Comparable<Kala> {
    private int shenaseKala;
    private String esm;
    private String berand;
    private double gheimat;
    private Forooshande forooshande;
    private NoeKala noeKala;
    private boolean mojoodi;
    private String tozihat;
    private boolean vaziateTaeideEzafeShodan = false;
    private VaziateDarkhasteTaghireEtteleat vaziateDarkhasteTaghireEtteleat =
            VaziateDarkhasteTaghireEtteleat.BEDOONE_DARKHAT;
    private double miangineNomreKharidaran;
    private ArrayList<Nazar> listeNazarat = new ArrayList<>();
    private ArrayList<Double> listeNomarat = new ArrayList<>();
    private ArrayList<Integer> listeIdeAfradeNazarDahande = new ArrayList<>();
    private ArrayList<Boolean> listeTaeidEKharideAfradeNazarDahande = new ArrayList<>();
    private int tedadNazarat;

    static public int shenaseha = 0;
    static public ArrayList<Kala> kolleKalaHa = new ArrayList<>();

    @Override
    public int compareTo(Kala kala) {

        if (this.noeKala != kala.noeKala) {
            if (this instanceof KalayeDigital) {
                return 1;
            } else if (kala instanceof KalayeDigital) {
                return -1;
            } else {
                if (this instanceof Pooshak) {
                    return 1;
                } else if (kala instanceof Pooshak) {
                    return -1;
                } else {
                    if (this instanceof LavazemKhanegi) {
                        return 1;
                    } else if (kala instanceof LavazemKhanegi) {
                        return -1;
                    } else {
                        if (this instanceof Khoraki) {
                            return 1;
                        } else if (kala instanceof Khoraki) {
                            return -1;
                        } else {
                            return 0;
                        }
                    }
                }
            }
        } else {
            if ((this instanceof Mobile && kala instanceof Mobile) ||
                    (this instanceof Laptop && kala instanceof Laptop) ||
                    (this instanceof Lebas && kala instanceof Lebas) ||
                    (this instanceof Kafsh && kala instanceof Kafsh) ||
                    (this instanceof Telvesion && kala instanceof Telvesion) ||
                    (this instanceof Yakhchal && kala instanceof Yakhchal) ||
                    (this instanceof Gaz && kala instanceof Gaz) ||
                    (this instanceof Khoraki && kala instanceof Khoraki)) {

                if (this.getEsm().compareTo(kala.getEsm()) > 0) {
                    return -1;
                } else if (this.getEsm().compareTo(kala.getEsm()) < 0) {
                    return 1;
                } else {
                    if (this instanceof Mobile){
                        Mobile mobile1= (Mobile) this;
                        Mobile mobile2= (Mobile) kala;
                        if (mobile1.getKeifiatDoorbin()>mobile2.getKeifiatDoorbin()){
                            return 1;
                        }
                        else if (mobile1.getKeifiatDoorbin()<mobile2.getKeifiatDoorbin()){
                            return -1;
                        }
                    }
                    else if (this instanceof Laptop){
                        Laptop laptop1= (Laptop) this;
                        Laptop laptop2= (Laptop) kala;
                        if (laptop1.getZarfiatRam()>laptop2.getZarfiatRam()){
                            return 1;
                        }
                        else if (laptop1.getZarfiatRam()<laptop2.getZarfiatRam()){
                            return -1;
                        }
                    }
                    else if (this instanceof Lebas){
                        Lebas lebas1= (Lebas) this;
                        Lebas lebas2= (Lebas) kala;
                        if (lebas1.getSize()>lebas2.getSize()){
                            return 1;
                        }
                        else if (lebas1.getSize()<lebas2.getSize()){
                            return -1;
                        }
                    }
                    else if (this instanceof Kafsh){
                        Kafsh kafsh1= (Kafsh) this;
                        Kafsh kafsh2= (Kafsh) kala;
                        if (kafsh1.getSize()>kafsh2.getSize()){
                            return 1;
                        }
                        else if (kafsh1.getSize()<kafsh2.getSize()){
                            return -1;
                        }
                    }
                    else if (this instanceof Telvesion){
                        Telvesion telvesion1= (Telvesion) this;
                        Telvesion telvesion2= (Telvesion) kala;
                        if (telvesion1.getSizeSafheNamayesh()>telvesion2.getSizeSafheNamayesh()){
                            return 1;
                        }
                        else if (telvesion1.getSizeSafheNamayesh()<telvesion2.getSizeSafheNamayesh()){
                            return -1;
                        }
                    }
                    else if (this instanceof Yakhchal){
                        Yakhchal yakhchal1= (Yakhchal) this;
                        Yakhchal yakhchal2= (Yakhchal) kala;
                        if (yakhchal1.getGonjayesh()>yakhchal2.getGonjayesh()){
                            return 1;
                        }
                        else if (yakhchal1.getGonjayesh()<yakhchal2.getGonjayesh()){
                            return -1;
                        }
                    }
                    else if (this instanceof Gaz){
                        Gaz gaz1= (Gaz) this;
                        Gaz gaz2= (Gaz) kala;
                        if (gaz1.getTedadShole()>gaz2.getTedadShole()){
                            return 1;
                        }
                        else if (gaz1.getTedadShole()<gaz2.getTedadShole()){
                            return -1;
                        }
                    }
                    else if (this instanceof Khoraki){
                        Khoraki khoraki1= (Khoraki) this;
                        Khoraki khoraki2= (Khoraki) kala;
                        if (khoraki1.getGheimat()>khoraki2.getGheimat()){
                            return 1;
                        }
                        else if (khoraki1.getGheimat()<khoraki2.getGheimat()){
                            return -1;
                        }
                    }
                    if (this.getMiangineNomreKharidaran() > kala.getMiangineNomreKharidaran()) {
                        return 1;
                    }
                    if (this.getMiangineNomreKharidaran() < kala.getMiangineNomreKharidaran()) {
                        return -1;
                    } else {
                        if (this.getGheimat() > kala.gheimat) {
                            return 1;
                        } else if (this.getGheimat() < kala.gheimat) {
                            return -1;
                        } else {
                            if (this.isMojoodi() && !kala.isMojoodi()) {
                                return 1;
                            }
                            if (kala.isMojoodi() && !this.isMojoodi()) {
                                return -1;
                            } else {
                                return 0;
                            }
                        }
                    }
                }
            }

            else {
                if (this.noeKala==NoeKala.KALAYE_DIGITAL){
                    if (this instanceof Mobile){
                        return 1;
                    }
                    else {
                        return -1;
                    }
                }
                else if (this.noeKala==NoeKala.POOSHAK){
                    if (this instanceof Lebas){
                        return 1;
                    }
                    else {
                        return -1;
                    }
                }
                else if (this.noeKala==NoeKala.LAVAZEM_KHANEGI){
                    if (this instanceof Telvesion){
                        return 1;
                    }
                    if (kala instanceof Telvesion){
                        return -1;
                    }
                    if (this instanceof Yakhchal){
                        return 1;
                    }
                    if (kala instanceof Yakhchal){
                        return -1;
                    }
                    if (this instanceof Gaz){
                        return 1;
                    }
                    if (kala instanceof Gaz){
                        return -1;
                    }
                    return 0;
                }
                else {
                    return 0;
                }
            }
        }
    }


    public Kala( String esm, String berand, double gheimat, Forooshande forooshande,
                 boolean mojoodi, String tozihat) {
        this.shenaseKala = shenaseha;
        this.esm = esm;
        this.berand = berand;
        this.gheimat = gheimat;
        this.forooshande = forooshande;
        this.mojoodi = mojoodi;
        this.tozihat = tozihat;
        this.miangineNomreKharidaran = 0.0;
        kolleKalaHa.add(this);
        shenaseha++;
    }

    @Override
    public String toString(){
        if(this.mojoodi)
            return " \n*********************"+
                    "\nshenase kala:"+this.shenaseKala+
                    "\nesm kala:"+this.esm+
                    "\nberand kala:"+this.berand+
                    "\ngheimat kala:"+this.gheimat+
                    "\nforooshande kala:"+this.forooshande.getNam()+
                    "\ntozihat kala:"+this.tozihat+
                    "\nmiangineNomreKharidaran kala:"+this.miangineNomreKharidaran+
                    "\nnoe kala:"+this.noeKala+
                    "\nmojoodi kala: bale"+
                    "\n*********************\n";
        else{
            return " \n*********************"+
                    "\nshenase kala:"+this.shenaseKala+
                    "\nesm kala:"+this.esm+
                    "\nberand kala:"+this.berand+
                    "\ngheimat kala:"+this.gheimat+
                    "\nforooshande kala:"+this.forooshande.getNam()+
                    "\ntozihat kala:"+this.tozihat+
                    "\nmiangineNomreKharidaran kala:"+this.miangineNomreKharidaran+
                    "\nnoe kala:"+this.noeKala+
                    "\nmojoodi kala: kheir"+
                    "\n*********************\n";
        }

    }

    public boolean isVaziateTaeideEzafeShodan() {
        return vaziateTaeideEzafeShodan;
    }
    public void setVaziateTaeideEzafeShodan(boolean vaziateTaeideEzafeShodan) {
        this.vaziateTaeideEzafeShodan = vaziateTaeideEzafeShodan;
    }
    public VaziateDarkhasteTaghireEtteleat getVaziateDarkhasteTaghireEtteleat() {
        return vaziateDarkhasteTaghireEtteleat;
    }

    public NoeKala getNoeKala() {
        return noeKala;
    }

    public void setNoeKala(NoeKala noeKala) {
        this.noeKala = noeKala;
    }

    public void setVaziateDarkhasteTaghireEtteleat(VaziateDarkhasteTaghireEtteleat vaziateDarkhasteTaghireEtteleat) {
        this.vaziateDarkhasteTaghireEtteleat = vaziateDarkhasteTaghireEtteleat;
    }
    public ArrayList<Integer> getListeIdeAfradeNazarDahande() {
        return listeIdeAfradeNazarDahande;
    }
    public void setListeIdeAfradeNazarDahande(ArrayList<Integer> listeIdeAfradeNazarDahande) {
        this.listeIdeAfradeNazarDahande = listeIdeAfradeNazarDahande;
    }
    public ArrayList<Boolean> getListeTaeidEKharideAfradeNazarDahande() {
        return listeTaeidEKharideAfradeNazarDahande;
    }
    public void setListeTaeidEKharideAfradeNazarDahande(ArrayList<Boolean> listeTaeidEKharideAfradeNazarDahande) {
        this.listeTaeidEKharideAfradeNazarDahande = listeTaeidEKharideAfradeNazarDahande;
    }
    public ArrayList<Nazar> getListeNazarat() {
        return listeNazarat;
    }
    public void setListeNazarat(ArrayList<Nazar> listeNazarat) {
        this.listeNazarat = listeNazarat;
    }
    public ArrayList<Kala> getKolleKalaHa() {
        return kolleKalaHa;
    }
    public void setKolleKalaHa(ArrayList<Kala> kolleKalaHa) {
        this.kolleKalaHa = kolleKalaHa;
    }
    public int getShenaseKala() {
        return shenaseKala;
    }
    public void setShenaseKala(int shenaseKala) {
        this.shenaseKala = shenaseKala;
    }
    public String getEsm() {
        return esm;
    }
    public void setEsm(String esm) {
        this.esm = esm;
    }
    public String getBerand() {
        return berand;
    }
    public void setBerand(String berand) {
        this.berand = berand;
    }
    public double getGheimat() {
        return gheimat;
    }
    public void setGheimat(double gheimat) {
        this.gheimat = gheimat;
    }
    public boolean isMojoodi() {
        return mojoodi;
    }
    public void setMojoodi(boolean mojoodi) {
        this.mojoodi = mojoodi;
    }
    public String getTozihat() {
        return tozihat;
    }
    public void setTozihat(String tozihat) {
        this.tozihat = tozihat;
    }
    public double getMiangineNomreKharidaran() {
        return miangineNomreKharidaran;
    }
    public void setMiangineNomreKharidaran(double miangineNomreKharidaran) {
        this.miangineNomreKharidaran = miangineNomreKharidaran;
    }
    public ArrayList<Nazar> getLesteNazarat() {
        return listeNazarat;
    }
    public void setLesteNazarat(ArrayList<Nazar> lesteNazarat) {
        this.listeNazarat = lesteNazarat;
    }
    public Forooshande getForooshande() {
        return forooshande;
    }
    public void setForooshande(Forooshande forooshande) {
        this.forooshande = forooshande;
    }
    public ArrayList<Double> getListeNomarat() {
        return listeNomarat;
    }
    public void setListeNomarat(ArrayList<Double> listeNomarat) {
        this.listeNomarat = listeNomarat;
    }
    public int getTedadNazarat() {
        return tedadNazarat;
    }
    public void setTedadNazarat(int tedadNazarat) {
        this.tedadNazarat = tedadNazarat;
    }
    public static int getShenaseha() {
        return shenaseha;
    }
    public static void setShenaseha(int shenaseha) {
        Kala.shenaseha = shenaseha;
    }

}
abstract class KalayeDigital extends Kala{
    private int zarfiatHafeze;
    private int zarfiatRam;
    private String systemAmel;
    private double vazn;
    private String abad;
    private NoeKalaDigital noeKalaDigital;

    public KalayeDigital( String esm, String berand, double gheimat, Forooshande forooshande,
                          boolean mojoodi, String tozihat,int zarfiatHafeze, int zarfiatRam,
                          String systemAmel, double vazn, String abad) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat);
        this.zarfiatHafeze = zarfiatHafeze;
        this.zarfiatRam = zarfiatRam;
        this.systemAmel = systemAmel;
        this.vazn = vazn;
        this.abad = abad;
        super.setNoeKala(NoeKala.KALAYE_DIGITAL);
    }

    public int getZarfiatHafeze() {
        return zarfiatHafeze;
    }
    public void setZarfiatHafeze(int zarfiatHafeze) {
        this.zarfiatHafeze = zarfiatHafeze;
    }
    public int getZarfiatRam() {
        return zarfiatRam;
    }
    public void setZarfiatRam(int zarfiatRam) {
        this.zarfiatRam = zarfiatRam;
    }
    public String getSystemAmel() {
        return systemAmel;
    }
    public void setSystemAmel(String systemAmel) {
        this.systemAmel = systemAmel;
    }
    public double getVazn() {
        return vazn;
    }
    public void setVazn(double vazn) {
        this.vazn = vazn;
    }
    public String getAbad() {
        return abad;
    }
    public void setAbad(String abad) {
        this.abad = abad;
    }

    public NoeKalaDigital getNoeKalaDigital() {
        return noeKalaDigital;
    }

    public void setNoeKalaDigital(NoeKalaDigital noeKalaDigital) {
        this.noeKalaDigital = noeKalaDigital;
    }
}
abstract class LavazemKhanegi extends Kala{
    private String darajeMasrafeEnergy;
    private boolean garanty;
    private NoeLavazemKhanegi noeLavazemKhanegi;

    public LavazemKhanegi( String esm, String berand, double gheimat, Forooshande forooshande,
                           boolean mojoodi, String tozihat, String darajeMasrafeEnergy, boolean garanty) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat);
        this.darajeMasrafeEnergy = darajeMasrafeEnergy;
        this.garanty = garanty;
        super.setNoeKala(NoeKala.LAVAZEM_KHANEGI);
    }

    public NoeLavazemKhanegi getNoeLavazemKhanegi() {
        return noeLavazemKhanegi;
    }

    public void setNoeLavazemKhanegi(NoeLavazemKhanegi noeLavazemKhanegi) {
        this.noeLavazemKhanegi = noeLavazemKhanegi;
    }

    public String getDarajeMasrafeEnergy() {
        return darajeMasrafeEnergy;
    }
    public void setDarajeMasrafeEnergy(String darajeMasrafeEnergy) {
        this.darajeMasrafeEnergy = darajeMasrafeEnergy;
    }
    public boolean isGaranty() {
        return garanty;
    }
    public void setGaranty(boolean garanty) {
        this.garanty = garanty;
    }
}
abstract class Pooshak extends Kala{
    private String keshvarTolidKonande;
    private String jens;
    private NoePooshak noePooshak;

    public Pooshak( String esm, String berand, double gheimat, Forooshande forooshande,
                    boolean mojoodi, String tozihat,
                    String keshvarTolidKonande, String jens) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat);
        this.keshvarTolidKonande = keshvarTolidKonande;
        this.jens = jens;
        super.setNoeKala(NoeKala.POOSHAK);
    }

    public NoePooshak getNoePooshak() {
        return noePooshak;
    }

    public void setNoePooshak(NoePooshak noePooshak) {
        this.noePooshak = noePooshak;
    }

    public String getJens() {
        return jens;
    }
    public void setJens(String jens) {
        this.jens = jens;
    }
    public String getKeshvarTolidKonande() {
        return keshvarTolidKonande;
    }
    public void setKeshvarTolidKonande(String keshvarTolidKonande) {
        this.keshvarTolidKonande = keshvarTolidKonande;
    }

}
class Khoraki extends Kala{
    private String tarikhTolid;
    private String tarikhEngheza;

    public Khoraki( String esm, String berand, double gheimat, Forooshande forooshande,
                    boolean mojoodi, String tozihat,
                    String tarikhTolid, String tarikhEngheza) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat);
        this.tarikhTolid = tarikhTolid;
        this.tarikhEngheza = tarikhEngheza;
        super.setNoeKala(NoeKala.KHORAKI);

    }

    public String getTarikhTolid() {
        return tarikhTolid;
    }
    public void setTarikhTolid(String tarikhTolid) {
        this.tarikhTolid = tarikhTolid;
    }
    public String getTarikhEngheza() {
        return tarikhEngheza;
    }
    public void setTarikhEngheza(String tarikhEngheza) {
        this.tarikhEngheza = tarikhEngheza;
    }
}
class Mobile extends KalayeDigital{
    private int tedadSimKart;
    private int keifiatDoorbin;

    public Mobile( String esm, String berand, double gheimat, Forooshande forooshande,
                   boolean mojoodi, String tozihat, int zarfiatHafeze, int zarfiatRam, String systemAmel,
                   double vazn, String abad, int tedadSimKart, int keifiatDoorbin) {
        super(esm, berand, gheimat, forooshande, mojoodi, tozihat,
                zarfiatHafeze, zarfiatRam, systemAmel, vazn, abad);
        this.tedadSimKart = tedadSimKart;
        this.keifiatDoorbin = keifiatDoorbin;
    }

    public int getTedadSimKart() {
        return tedadSimKart;
    }
    public void setTedadSimKart(int tedadSimKart) {
        this.tedadSimKart = tedadSimKart;
    }
    public int getKeifiatDoorbin() {
        return keifiatDoorbin;
    }
    public void setKeifiatDoorbin(int keifiatDoorbin) {
        this.keifiatDoorbin = keifiatDoorbin;
    }
}
class Laptop extends KalayeDigital{
    private String modelePardazande;
    private boolean gaming;

    public Laptop( String esm, String berand, double gheimat, Forooshande forooshande,
                   boolean mojoodi, String tozihat, int zarfiatHafeze, int zarfiatRam,
                   String systemAmel, double vazn, String abad, String modelePardazande, boolean gaming) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat,
                zarfiatHafeze, zarfiatRam, systemAmel, vazn, abad);
        this.modelePardazande = modelePardazande;
        this.gaming = gaming;
    }

    public String getModelePardazande() {
        return modelePardazande;
    }
    public void setModelePardazande(String modelePardazande) {
        this.modelePardazande = modelePardazande;
    }
    public boolean isGaming() {
        return gaming;
    }
    public void setGaming(boolean gaming) {
        this.gaming = gaming;
    }
}
class Lebas extends Pooshak{
    private int size;
    private NoeLebas noeLebas;

    public Lebas( String esm, String berand, double gheimat, Forooshande forooshande,
                  boolean mojoodi, String tozihat, String keshvarTolidKonande, String jens,
                  int size, NoeLebas noeLebas) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat,
                keshvarTolidKonande, jens);
        this.size = size;
        this.noeLebas = noeLebas;
        super.setNoePooshak(NoePooshak.LEBAS);
    }

    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        this.size = size;
    }
    public NoeLebas getNoeLebas() {
        return noeLebas;
    }
    public void setNoeLebas(NoeLebas noeLebas) {
        this.noeLebas = noeLebas;
    }
}
class Kafsh extends Pooshak{
    private int size;
    private NoeKafsh noeKafsh;

    public Kafsh( String esm, String berand, double gheimat, Forooshande forooshande,
                  boolean mojoodi, String tozihat,
                  String keshvarTolidKonande, String jens,
                  int size, NoeKafsh noeKafsh) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat
                , keshvarTolidKonande, jens);
        this.size = size;
        this.noeKafsh = noeKafsh;
        super.setNoePooshak(NoePooshak.KAFSH);
    }

    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        this.size = size;
    }
    public NoeKafsh getNoeKafsh() {
        return noeKafsh;
    }
    public void setNoeKafsh(NoeKafsh noeKafsh) {
        this.noeKafsh = noeKafsh;
    }
}
class Telvesion extends LavazemKhanegi{
    private String keifiatTasvir;
    private double sizeSafheNamayesh;

    public Telvesion( String esm, String berand, double gheimat, Forooshande forooshande,
                      boolean mojoodi, String tozihat, String darajeMasrafeEnergy, boolean garanty,
                      String keifiatTasvir, double sizeSafheNamayesh) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat, darajeMasrafeEnergy, garanty);
        this.keifiatTasvir = keifiatTasvir;
        this.sizeSafheNamayesh = sizeSafheNamayesh;
        super.setNoeLavazemKhanegi(NoeLavazemKhanegi.TELVISION);
    }

    public String getKeifiatTasvir() {
        return keifiatTasvir;
    }
    public void setKeifiatTasvir(String keifiatTasvir) {
        this.keifiatTasvir = keifiatTasvir;
    }
    public double getSizeSafheNamayesh() {
        return sizeSafheNamayesh;
    }
    public void setSizeSafheNamayesh(double sizeSafheNamayesh) {
        this.sizeSafheNamayesh = sizeSafheNamayesh;
    }
}
class Yakhchal extends LavazemKhanegi{
    private String noeYakhchal;
    private double gonjayesh;
    private boolean Fereizer;

    public Yakhchal(String esm, String berand, double gheimat, Forooshande forooshande,
                    boolean mojoodi, String tozihat, String darajeMasrafeEnergy,
                    boolean garanty, String noeYakhchal, double gonjayesh, boolean fereizer) {
        super(esm, berand, gheimat, forooshande, mojoodi, tozihat, darajeMasrafeEnergy, garanty);
        this.noeYakhchal = noeYakhchal;
        this.gonjayesh = gonjayesh;
        Fereizer = fereizer;
        super.setNoeLavazemKhanegi(NoeLavazemKhanegi.YAKHCHAL);
    }

    public String getNoeYakhchal() {
        return noeYakhchal;
    }
    public void setNoeYakhchal(String noeYakhchal) {
        this.noeYakhchal = noeYakhchal;
    }
    public double getGonjayesh() {
        return gonjayesh;
    }
    public void setGonjayesh(double gonjayesh) {
        this.gonjayesh = gonjayesh;
    }
    public boolean isFereizer() {
        return Fereizer;
    }
    public void setFereizer(boolean fereizer) {
        Fereizer = fereizer;
    }
}
class Gaz extends LavazemKhanegi{
    private int tedadShole;
    private String jens;
    private boolean fer;

    public Gaz( String esm, String berand, double gheimat, Forooshande forooshande,
                boolean mojoodi, String tozihat,
                String darajeMasrafeEnergy, boolean garanty, int tedadShole,
                String jens, boolean fer) {
        super( esm, berand, gheimat, forooshande, mojoodi, tozihat,
                darajeMasrafeEnergy, garanty);
        this.tedadShole = tedadShole;
        this.jens = jens;
        this.fer = fer;
        super.setNoeLavazemKhanegi(NoeLavazemKhanegi.GAZ);
    }

    public int getTedadShole() {
        return tedadShole;
    }
    public void setTedadShole(int tedadShole) {
        this.tedadShole = tedadShole;
    }
    public String getJens() {
        return jens;
    }
    public void setJens(String jens) {
        this.jens = jens;
    }
    public boolean isFer() {
        return fer;
    }
    public void setFer(boolean fer) {
        this.fer = fer;
    }
}
//--------------------------------------------------
enum NoeKafsh{
    BOOT,MAJLESI,SPORT;
}
enum NoeLebas{
    T_SHIRT,SHALVAR,PIRHAN;
}
enum Naghsh{
    KHARIDAR,FOROOSHANDE,MODIR;
}
enum VaziateDarkhasteTaghireEtteleat{
    BEDOONE_DARKHAT,DAR_ENTEZAR,TAEID,RAD;
}
enum VaziateNazar{
    DAR_ENTEZARE_TAEID,TAEID_SHODE,TAEID_NASHODE;
}
enum NoeKala{
    KALAYE_DIGITAL,POOSHAK,LAVAZEM_KHANEGI,KHORAKI;
}
enum NoeKalaDigital{
    MOBILE,LAPTOP
}
enum NoePooshak{
    LEBAS,KAFSH;
}
enum NoeLavazemKhanegi{
    TELVISION,YAKHCHAL,GAZ;
}

class HandelException{
    static int handelExceptionI(){
        Scanner sc=new Scanner(System.in);
        String s1=sc.next();
        try {
            Integer.parseInt(s1);
        } catch (NumberFormatException e) {
            System.out.println("voroudi namotar ast! (HE) int");
            return -1;
        }
        int s11=Integer.parseInt(s1);
        return s11;
    }
    static Double handelExceptionD(){
        Scanner sc=new Scanner(System.in);
        String s1=sc.next();
        try {
            Double.parseDouble(s1);
        } catch (NumberFormatException e) {
            System.out.println("voroudi namotar ast! (HE) double");
            return -1.1;
        }
        double s11=Double.parseDouble(s1);
        return s11;
    }
    static long handelShomareTelephone(){
        Scanner sc=new Scanner(System.in);
        String s1=sc.next();
        try {
            Long.parseLong(s1);
            //Integer.parseInt(s1);
        }
         catch (NumberFormatException e) {
            System.out.println("formate adad sahih nist ! (HE sh)");
            return -1;
        }
        try {
            long voroodi2=Long.parseLong(s1);
            int size=s1.length();
            char[] v2=s1.toCharArray();
            if (size==12 && v2[0]==57 && v2[1]==56){
                return voroodi2;
            }
            else {
                return -1;
            }
        } catch (NumberFormatException e) {
            System.out.println("formate adadi sahih nist !");
            return -1;
        }
    }
    static int barresiEmail(String email){
        int size=email.length();
        if (size<11){
            return 0;
        }
        String sub=email.substring(size-10,size);
        if (sub.compareTo("@gmail.com")==0){
            return 1;
        }
        else {
            return 0;
        }
    }
}

class Write{
    static void writeForoushande(Forooshande f,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :" +f.getNam());
        pw.println("ramze obour :" +f.getRamzeOboor());
        pw.println("shomare telephone :" +f.getShomareTelephon());
        pw.println("name karbari :" +f.getNameKarbari());
        pw.println("email :" +f.getEmail());
        pw.close();
    }
    static void writeKharidar(Kharidar kh,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :" +kh.getNam());
        pw.println("ramze obour :" +kh.getRamzeOboor());
        pw.println("shomare telephone :" +kh.getShomareTelephon());
        pw.println("name karbari :" +kh.getNameKarbari());
        pw.println("email :" +kh.getEmail());
        pw.close();
    }
    static void writeMobile(Mobile mobile,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+mobile.getEsm());
        pw.println("abad :"+mobile.getAbad());
        pw.println("tedad sim :"+mobile.getTedadSimKart());
        pw.println("keifiat dourbin :"+mobile.getKeifiatDoorbin());
        pw.println("name foroushande :"+mobile.getForooshande().getNam());
        pw.println("berand :"+mobile.getBerand());
        pw.println("system amel :"+mobile.getSystemAmel());
        pw.println("tozihat :"+mobile.getTozihat());
        pw.println("gheimat :"+mobile.getGheimat());
        pw.println("miangin nomre kharidaran :"+mobile.getMiangineNomreKharidaran());
        pw.println("vazn :"+mobile.getVazn());
        System.out.println();
        System.out.println();
        pw.close();
    }
    static void writeKhoraki(Khoraki khoraki,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+khoraki.getEsm());
        pw.println("gheimat :"+khoraki.getGheimat());
        pw.println("berand :"+khoraki.getBerand());
        pw.println("tarikh engheza :"+khoraki.getTarikhEngheza());
        System.out.println();
        pw.close();
    }

    static void writeLaptop(Laptop laptop,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+laptop.getEsm());
        pw.println("abad :"+laptop.getAbad());
        pw.println("zarfiat ram :"+laptop.getZarfiatRam());
        pw.println("modele pardazande :"+laptop.getModelePardazande());
        System.out.println();
        pw.close();
    }
    static void writeLebas(Lebas lebas,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+lebas.getEsm());
        pw.println("size :"+lebas.getSize());
        pw.println("berand :"+lebas.getBerand());
        pw.println("jens :"+lebas.getJens());
        System.out.println();
        pw.close();
    }
    static void writeKafsh(Kafsh kafsh,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+kafsh.getEsm());
        pw.println("size :"+kafsh.getSize());
        pw.println("berand :"+kafsh.getBerand());
        pw.println("jens :"+kafsh.getJens());
        System.out.println();
        pw.close();
    }
    static void writeTelvesion(Telvesion telvesion,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+telvesion.getEsm());
        pw.println("daraje masrafe energy :"+telvesion.getDarajeMasrafeEnergy());
        pw.println("berand :"+telvesion.getBerand());
        pw.println("gheimat :"+telvesion.getGheimat());
        System.out.println();
        pw.close();
    }
    static void writeYakhchal(Yakhchal yakhchal,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+yakhchal.getEsm());
        pw.println("daraje masrafe energy :"+yakhchal.getDarajeMasrafeEnergy());
        pw.println("berand :"+yakhchal.getBerand());
        pw.println("gheimat :"+yakhchal.getGheimat());
        System.out.println();
        pw.close();
    }
    static void writeGaz(Gaz gaz,String str) throws FileNotFoundException {
        PrintWriter pw=new PrintWriter(str);
        pw.println("nam :"+gaz.getEsm());
        pw.println("daraje masrafe energy :"+gaz.getDarajeMasrafeEnergy());
        pw.println("berand :"+gaz.getBerand());
        pw.println("gheimat :"+gaz.getGheimat());
        System.out.println();
        pw.close();
    }

}

class KharidNaMotabar extends Exception {
    KharidNaMotabar(){}
    public String toString(){
        return "kharid namotabar ast!";
    }
}



 class EmailNaMotabar extends KharidNaMotabar{
     EmailNaMotabar(){}
    public String toString(){
        return "email motabar nemibashad!\n"+
                super.toString();
    }
}



 class VoroudiNaMotabar extends Exception {
     VoroudiNaMotabar(){}
    public String toString() {
        return "voroudi namotabar ast!";
    }
}



class AdamMojoudiKala extends KharidNaMotabar{
    AdamMojoudiKala(){}
    public String toString(){
        return "kharid namotabar ast!\n"+
                super.toString();
    }
}

class TelephoneNaMotabar extends VoroudiNaMotabar{
    TelephoneNaMotabar(){}
    public String toString(){
        return "telephone namotabar ast!\n"+
                super.toString();
    }
}

class AdamMojoudiEtebar extends KharidNaMotabar {
    AdamMojoudiEtebar(){}
    public String toString(){
        return "etebar kafi nemibashad!\n"+
                super.toString();
    }
}
